import pytest

from app.services.export_safety import safe_rate, sample_status, sanitize_cell, summary_rows, to_csv


@pytest.mark.parametrize("value", ["=1+1", "+cmd", "-2+3", "@SUM(A1)", "\t=x", "\r=x"])
def test_formula_cells_are_neutralised(value):
    assert sanitize_cell(value) == "'" + value


@pytest.mark.parametrize("value", ["Nurse", "", "a=b", 5, -3, 0.2, None])
def test_normal_cells_are_untouched(value):
    assert sanitize_cell(value) == value


def test_to_csv_sanitizes_header_and_cells():
    out = to_csv(["=bad", "ok"], [["@evil", 1], ["fine", -1]])
    lines = out.splitlines()
    assert lines[0] == "'=bad,ok"
    assert lines[1] == "'@evil,1"
    assert lines[2] == "fine,-1"          # a real negative number is not a formula


@pytest.mark.parametrize("n,expected", [(0, "withheld"), (4, "withheld"), (5, "small_sample"), (29, "small_sample"), (30, "ok"), (917, "ok")])
def test_sample_status_thresholds(n, expected):
    assert sample_status(n) == expected


def test_rate_withheld_below_five():
    assert safe_rate(1, 4) is None and safe_rate(0, 0) is None
    assert safe_rate(1, 5) == 0.2


def test_summary_rows_withhold_rate_and_ci_for_tiny_groups_and_flag_small_ones():
    analysis = {"dimension": "ward", "note": "n", "test": {"p_value": 0.2},
                "rows": [{"group": "A", "n": 3, "complied": 1, "rate": 1 / 3, "ci_low": 0.1, "ci_high": 0.8},
                         {"group": "B", "n": 10, "complied": 2, "rate": 0.2, "ci_low": 0.05, "ci_high": 0.5},
                         {"group": "C", "n": 100, "complied": 20, "rate": 0.2, "ci_low": 0.13, "ci_high": 0.29}]}
    header, rows = summary_rows([analysis])
    a, b, c = rows
    assert a[header.index("rate")] == "" and a[header.index("ci_low")] == "" and a[header.index("sample_flag")] == "withheld"
    assert b[header.index("sample_flag")] == "small_sample" and b[header.index("rate")] == 0.2
    assert c[header.index("sample_flag")] == "ok"
    assert a[header.index("n")] == 3                      # n is always shown
