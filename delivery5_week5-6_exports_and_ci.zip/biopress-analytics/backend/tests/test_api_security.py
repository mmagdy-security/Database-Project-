"""API security and DB-backed API, end to end on SQLite files (the same code runs on PostgreSQL).

Covers the Definition of Done of the Database & Security plan:
- importing the original file creates 917 rows and the summary endpoint returns 202 / 917
- a file with a missing column or unknown Complied value is rejected with a clear message
- a viewer token cannot call import, train or user endpoints
- audit_log records logins, imports and exports
"""
import pytest

pytest.importorskip("fastapi")
pytest.importorskip("sqlalchemy")
pytest.importorskip("argon2")

from fastapi import FastAPI  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy import create_engine, func, select  # noqa: E402
from sqlalchemy.orm import sessionmaker  # noqa: E402

from app.api import deps  # noqa: E402
from app.api import ml as ml_api  # noqa: E402
from app.config import get_settings  # noqa: E402
from app.db.models import AuditLog, Base, Opportunity, User  # noqa: E402
from app.db.sql_views import VIEWS  # noqa: E402
from app.main import app  # noqa: E402
from app.security.passwords import hash_password  # noqa: E402
from app.security.tokens import create_access_token  # noqa: E402
from app.services.import_service import ensure_reference_data  # noqa: E402

PASSWORD = "correct horse battery staple"


@pytest.fixture
def env(tmp_path, monkeypatch):
    url = f"sqlite:///{tmp_path / 'api.db'}"
    monkeypatch.setenv("DATABASE_URL", url)
    monkeypatch.setenv("DATA_SOURCE", "db")
    monkeypatch.setenv("REQUIRE_AUTH", "true")
    monkeypatch.setenv("UPLOAD_DIR", str(tmp_path / "uploads"))
    deps.login_limiter.reset()
    deps.import_limiter.reset()
    engine = create_engine(url)
    Base.metadata.create_all(engine)
    with engine.begin() as conn:
        for sql in VIEWS.values():
            conn.exec_driver_sql(sql)
    Session = sessionmaker(bind=engine, expire_on_commit=False)
    with Session() as s:
        ensure_reference_data(s)
        for name, role in (("admin1", "admin"), ("analyst1", "analyst"), ("viewer1", "viewer")):
            s.add(User(username=name, role=role, password_hash=hash_password(PASSWORD)))
        s.commit()
    return Session


@pytest.fixture
def client(env):
    return TestClient(app)


def token(username, role, uid=None):
    return create_access_token(username=username, role=role, user_id=uid, settings=get_settings())


def auth(username, role):
    return {"Authorization": f"Bearer {token(username, role)}"}


def upload(client, data, headers, path="preview", name="data.csv", **form):
    return client.post(f"/api/v1/imports/{path}", files={"file": (name, data, "text/csv")}, data=form, headers=headers)


def sha_of(data):
    import hashlib
    return hashlib.sha256(data).hexdigest()


# ---------- authentication / authorization ----------

PROTECTED = [("GET", "/api/v1/analytics/summary", 1), ("GET", "/api/v1/analytics/by-ward", 1),
             ("GET", "/api/v1/exports/summary.csv", 2), ("GET", "/api/v1/admin/users", 3),
             ("POST", "/api/v1/imports/preview", 3), ("POST", "/api/v1/imports/confirm", 3), ("GET", "/api/v1/imports", 3)]


@pytest.mark.parametrize("method,path,min_rank", PROTECTED)
def test_no_token_is_401(client, method, path, min_rank):
    assert client.request(method, path).status_code == 401


@pytest.mark.parametrize("method,path,min_rank", [p for p in PROTECTED if p[2] > 1])
def test_viewer_token_is_forbidden_on_import_user_and_export_endpoints(client, method, path, min_rank):
    assert client.request(method, path, headers=auth("viewer1", "viewer")).status_code == 403


def test_viewer_cannot_create_users_or_train(client):
    h = auth("viewer1", "viewer")
    assert client.post("/api/v1/admin/users", headers=h, json={"username": "x" * 5, "password": PASSWORD, "role": "admin"}).status_code == 403
    mini = FastAPI()
    mini.include_router(ml_api.router)
    c = TestClient(mini)
    assert c.post("/api/v1/ml/train", headers=h).status_code == 403
    assert c.post("/api/v1/ml/train", headers=auth("analyst1", "analyst")).status_code == 403
    assert c.post("/api/v1/ml/train").status_code == 401


def test_training_route_does_not_exist_outside_development(client):
    # APP_ENV=test here, so main.py never registered it
    assert client.post("/api/v1/ml/train", headers=auth("admin1", "admin")).status_code in (404, 405)


def test_analyst_cannot_import_or_manage_users_but_can_export(client):
    h = auth("analyst1", "analyst")
    assert client.get("/api/v1/admin/users", headers=h).status_code == 403
    assert upload(client, b"x", h).status_code == 403


def test_forged_role_in_token_does_not_help_a_disabled_or_demoted_account(client, env):
    with env() as s:
        u = s.scalar(select(User).where(User.username == "admin1"))
        u.role = "viewer"
        s.commit()
    assert client.get("/api/v1/admin/users", headers=auth("admin1", "admin")).status_code == 403   # DB role wins
    with env() as s:
        u = s.scalar(select(User).where(User.username == "admin1"))
        u.role, u.is_active = "admin", False
        s.commit()
    assert client.get("/api/v1/admin/users", headers=auth("admin1", "admin")).status_code == 401


def test_garbage_and_expired_tokens_are_401(client):
    assert client.get("/api/v1/analytics/summary", headers={"Authorization": "Bearer not.a.jwt"}).status_code == 401
    from datetime import datetime, timedelta, timezone
    old = create_access_token(username="viewer1", role="viewer", user_id=None, settings=get_settings(),
                              now=datetime.now(timezone.utc) - timedelta(hours=2))
    assert client.get("/api/v1/analytics/summary", headers={"Authorization": f"Bearer {old}"}).status_code == 401


def test_login_success_failure_audit_and_rate_limit(client, env):
    ok = client.post("/api/v1/auth/login", json={"username": "viewer1", "password": PASSWORD})
    assert ok.status_code == 200 and ok.json()["token_type"] == "bearer"
    assert client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {ok.json()['access_token']}"}).json()["role"] == "viewer"
    bad = client.post("/api/v1/auth/login", json={"username": "viewer1", "password": "wrong password!!"})
    unknown = client.post("/api/v1/auth/login", json={"username": "nobody", "password": "wrong password!!"})
    assert bad.status_code == unknown.status_code == 401 and bad.json() == unknown.json()   # no user enumeration
    with env() as s:
        actions = list(s.scalars(select(AuditLog.action).order_by(AuditLog.id)))
        assert actions.count("login_ok") == 1 and actions.count("login_failed") == 2
        assert PASSWORD not in str([a.details for a in s.scalars(select(AuditLog))])
    codes = [client.post("/api/v1/auth/login", json={"username": "viewer1", "password": "wrong password!!"}).status_code for _ in range(12)]
    assert 429 in codes


def test_admin_can_create_user_and_weak_password_is_rejected(client):
    h = auth("admin1", "admin")
    assert client.post("/api/v1/admin/users", headers=h, json={"username": "new.user", "password": "short", "role": "viewer"}).status_code == 422
    r = client.post("/api/v1/admin/users", headers=h, json={"username": "new.user", "password": PASSWORD, "role": "viewer"})
    assert r.status_code == 201 and "password" not in r.text


# ---------- import flow ----------

def test_import_original_file_then_summary_is_917_202(client, env, raw_csv_bytes, tmp_path):
    h = auth("admin1", "admin")
    p = upload(client, raw_csv_bytes, h)
    assert p.status_code == 200
    body = p.json()
    assert body["ok"] and body["can_confirm"] and body["row_count"] == 917 and body["complied_yes"] == 202
    assert {w["code"] for w in body["warnings"]} == {"duplicate_source_opp", "missing_source_opp_in_sequence"}
    with env() as s:                                              # preview writes nothing
        assert s.scalar(select(func.count()).select_from(Opportunity)) == 0

    c = upload(client, raw_csv_bytes, h, "confirm", expected_sha256=body["sha256"])
    assert c.status_code == 201 and c.json()["row_count"] == 917

    s = client.get("/api/v1/analytics/summary", headers=auth("viewer1", "viewer")).json()
    assert (s["opportunities"], s["actions"], round(s["compliance_rate"] * 100, 1)) == (917, 202, 22.0)
    raw_copy = tmp_path / "uploads" / f"{body['sha256']}.csv"
    assert raw_copy.read_bytes() == raw_csv_bytes                  # raw upload kept byte-for-byte
    with env() as s2:
        assert {"import_preview", "import_confirm"} <= set(s2.scalars(select(AuditLog.action)))

    again = upload(client, raw_csv_bytes, h, "confirm", expected_sha256=body["sha256"])
    assert again.status_code == 409                                # same file cannot be imported twice
    assert upload(client, raw_csv_bytes, h).json()["already_imported"] is True


def test_confirm_refuses_a_different_file_than_the_one_previewed(client, raw_csv_bytes):
    r = upload(client, raw_csv_bytes, auth("admin1", "admin"), "confirm", expected_sha256="0" * 64)
    assert r.status_code == 409


def test_bad_files_are_rejected_with_clear_messages(client, raw_csv_bytes):
    h = auth("admin1", "admin")
    no_shift = raw_csv_bytes.decode("utf-8-sig").replace("Shift", "Shifts", 1).encode()
    r = upload(client, no_shift, h).json()
    assert not r["ok"] and not r["can_confirm"] and r["errors"][0]["code"] == "missing_columns" and "Shift" in r["errors"][0]["message"]
    bad_value = raw_csv_bytes.decode("utf-8-sig").replace(",No\r\n", ",Perhaps\r\n", 1).replace(",No\n", ",Perhaps\n", 1).encode()
    r = upload(client, bad_value, h).json()
    assert not r["ok"] and any(e["code"] == "invalid_complied" for e in r["errors"])
    c = upload(client, no_shift, h, "confirm", expected_sha256=sha_of(no_shift))
    assert c.status_code == 422
    assert upload(client, b"a,b\n1,2\n", h, name="x.txt").json()["errors"][0]["code"] == "file_type"


def test_oversized_upload_is_rejected(client, monkeypatch, raw_csv_bytes):
    monkeypatch.setenv("MAX_UPLOAD_BYTES", "1000")
    r = upload(client, raw_csv_bytes, auth("admin1", "admin")).json()
    assert r["errors"][0]["code"] == "file_too_large"


# ---------- exports ----------

def test_export_is_audited_has_no_formula_cells_and_withholds_nothing_for_this_data(client, env, raw_csv_bytes):
    upload(client, raw_csv_bytes, auth("admin1", "admin"), "confirm", expected_sha256=sha_of(raw_csv_bytes))
    r = client.get("/api/v1/exports/summary.csv", headers=auth("analyst1", "analyst"))
    assert r.status_code == 200 and r.headers["content-type"].startswith("text/csv")
    for line in r.text.splitlines()[1:]:
        assert not line.startswith(("=", "+", "-", "@"))
    assert "n,complied,rate" in r.text.splitlines()[0]
    with env() as s:
        assert "export" in set(s.scalars(select(AuditLog.action)))


def test_security_headers_present(client):
    r = client.get("/health")
    assert r.headers["x-content-type-options"] == "nosniff" and r.headers["x-frame-options"] == "DENY"


def test_empty_database_gives_503_not_a_crash(client):
    assert client.get("/api/v1/analytics/summary", headers=auth("viewer1", "viewer")).status_code == 503
