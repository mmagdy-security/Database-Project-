from fastapi import Depends, FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api import auth, exports, imports
from app.api import ml as ml_api
from app.api.deps import read_access
from app.config import get_settings
from app.schemas.analytics import GroupAnalysis, Summary
from app.services import analytics
from app.services.frame_source import NoDataError, get_frame

settings = get_settings()
app = FastAPI(title="BIOPRESS Analytics", version="0.2.0")

# CORS: only the known frontend origin(s). Bearer tokens travel in the Authorization header, so no cookies/credentials.
app.add_middleware(CORSMiddleware, allow_origins=list(settings.cors_origins), allow_credentials=False,
                   allow_methods=["GET", "POST"], allow_headers=["Authorization", "Content-Type"])

_DOC_PATHS = ("/docs", "/redoc", "/openapi.json")


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    if not request.url.path.startswith(_DOC_PATHS):          # Swagger UI needs its own scripts
        response.headers["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'"
        response.headers["Cache-Control"] = "no-store"
    if get_settings().env == "production":
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response


@app.exception_handler(NoDataError)
async def no_data_handler(request: Request, exc: NoDataError):
    return JSONResponse(status_code=503, content={"detail": str(exc)})


app.include_router(auth.router)
app.include_router(imports.router)
app.include_router(exports.router)
if settings.env == "development":                            # training endpoint exists only in development
    app.include_router(ml_api.router)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/api/v1/analytics/summary", response_model=Summary, dependencies=[Depends(read_access)])
def get_summary():
    return analytics.summary(get_frame())


def _group_endpoint(dimension: str):
    def handler():
        return analytics.by_group(get_frame(), dimension)
    return handler


for _dim, _path in [("ward", "by-ward"), ("shift", "by-shift"), ("indication", "by-indication"), ("profcat", "by-profcat")]:
    app.add_api_route(f"/api/v1/analytics/{_path}", _group_endpoint(_dim), methods=["GET"],
                      response_model=GroupAnalysis, dependencies=[Depends(read_access)])
