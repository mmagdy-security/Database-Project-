"""Exports (analyst or admin). Only aggregated groups, never individual records, never anything per person."""
from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy.orm import Session

from app.api.deps import client_ip, require_fresh_role
from app.db.session import get_session
from app.security.tokens import Principal
from app.services import analytics, audit, export_safety
from app.services.frame_source import get_frame

router = APIRouter(prefix="/api/v1/exports", tags=["exports"])


@router.get("/summary.csv")
def export_summary(request: Request, user: Principal = Depends(require_fresh_role("analyst")),
                   session: Session = Depends(get_session)):
    df = get_frame()
    analyses = [analytics.by_group(df, d) for d in ("indication", "ward", "shift", "profcat")]
    header, rows = export_safety.summary_rows(analyses)
    body = export_safety.to_csv(header, rows)
    audit.record(session, "export", user_id=user.user_id, username=user.username, resource="summary.csv",
                 ip=client_ip(request), details={"rows": len(rows)})
    session.commit()
    return Response(content=body, media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": 'attachment; filename="biopress_summary.csv"'})
