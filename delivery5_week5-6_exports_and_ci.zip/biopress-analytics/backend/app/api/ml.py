"""Security gate for ML training. The AI team fills in the body (backend/app/ml).

- Registered ONLY when APP_ENV=development (see main.py): in test/production the route does not exist (404).
- Requires an admin whose account is still active.
- Every call is audited.
"""
from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from app.api.deps import client_ip, require_fresh_role
from app.db.session import get_session
from app.security.tokens import Principal
from app.services import audit

router = APIRouter(prefix="/api/v1/ml", tags=["ml"])


@router.post("/train")
def train(request: Request, admin: Principal = Depends(require_fresh_role("admin")),
          session: Session = Depends(get_session)):
    audit.record(session, "model_train", user_id=admin.user_id, username=admin.username, ip=client_ip(request))
    session.commit()
    # AI team: read training data ONLY from the v_ml_features view (see app/services/db_loader.py).
    raise HTTPException(status.HTTP_501_NOT_IMPLEMENTED, "Training is implemented by the AI team.")
