"""CSV export safety and small-sample rules.

- Cells that start with = + - @ (or tab / carriage return) are neutralised with a leading
  apostrophe so spreadsheet programs do not run them as formulas (CSV injection, OWASP).
- Rates for n < 5 are withheld; groups with n < 30 get a small-sample warning.
"""
from __future__ import annotations

import csv
import io
import math
from typing import Iterable, Sequence

FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")
WITHHOLD_BELOW = 5
WARN_BELOW = 30


def sanitize_cell(value):
    """Only strings can be formulas. Real numbers (including negatives) are left as numbers."""
    if isinstance(value, str) and value.startswith(FORMULA_PREFIXES):
        return "'" + value
    return value


def to_csv(header: Sequence[str], rows: Iterable[Sequence]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow([sanitize_cell(h) for h in header])
    for row in rows:
        w.writerow([sanitize_cell(cell) for cell in row])
    return buf.getvalue()


def sample_status(n: int) -> str:
    """'withheld' (n < 5), 'small_sample' (5 <= n < 30) or 'ok'."""
    if n < WITHHOLD_BELOW:
        return "withheld"
    if n < WARN_BELOW:
        return "small_sample"
    return "ok"


def safe_rate(k: int, n: int):
    """Rate, or None when it must be withheld."""
    if sample_status(n) == "withheld" or n == 0:
        return None
    return k / n


def _num(x):
    return "" if x is None or (isinstance(x, float) and math.isnan(x)) else round(x, 4)


def summary_rows(analyses: Iterable[dict]) -> tuple[list[str], list[list]]:
    """Flatten analytics.by_group() results into export rows. Never contains per-person data."""
    header = ["dimension", "group", "n", "complied", "rate", "ci_low", "ci_high", "sample_flag", "chi_square_p", "note"]
    out: list[list] = []
    for a in analyses:
        for r in a["rows"]:
            status = sample_status(r["n"])
            hidden = status == "withheld"
            out.append([a["dimension"], r["group"], r["n"], r["complied"],
                        "" if hidden else _num(r["rate"]),
                        "" if hidden else _num(r["ci_low"]),
                        "" if hidden else _num(r["ci_high"]),
                        status, _num(a["test"]["p_value"]), a["note"]])
    return header, out
