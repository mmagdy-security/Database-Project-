#!/usr/bin/env python3
"""Create the first admin interactively. The password is typed (never passed on the command line,
never stored in the repository). There are no default accounts.

    cd backend && python ../scripts/create_admin.py <username>
"""
import getpass
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from sqlalchemy import select  # noqa: E402
from sqlalchemy.orm import sessionmaker  # noqa: E402

from app.db.models import User  # noqa: E402
from app.db.session import get_engine  # noqa: E402
from app.security.passwords import hash_password  # noqa: E402


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print(__doc__)
        return 2
    username = argv[1]
    pw = getpass.getpass("Password (min 12 chars): ")
    if pw != getpass.getpass("Repeat password: "):
        print("Passwords do not match.")
        return 1
    try:
        hashed = hash_password(pw)
    except ValueError as exc:
        print(exc)
        return 1
    with sessionmaker(bind=get_engine())() as s:
        if s.scalar(select(User.id).where(User.username == username)):
            print("User already exists.")
            return 1
        s.add(User(username=username, role="admin", password_hash=hashed))
        s.commit()
    print(f"Admin '{username}' created.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
