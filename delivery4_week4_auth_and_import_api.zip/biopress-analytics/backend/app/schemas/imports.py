from pydantic import BaseModel


class IssueOut(BaseModel):
    code: str
    message: str
    count: int
    examples: list


class ImportPreviewOut(BaseModel):
    filename: str
    sha256: str
    size_bytes: int
    row_count: int
    ok: bool
    complied_yes: int | None
    complied_no: int | None
    errors: list[IssueOut]
    warnings: list[IssueOut]
    preview: list[dict]
    already_imported: bool
    can_confirm: bool


class ImportCommitOut(BaseModel):
    import_id: int
    sha256: str
    row_count: int
    complied_yes: int
    warnings: list[IssueOut]
