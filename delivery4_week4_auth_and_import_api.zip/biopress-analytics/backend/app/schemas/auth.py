from pydantic import BaseModel, Field

from app.db.constants import ROLES


class LoginIn(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=256)


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int


class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=64, pattern=r"^[A-Za-z0-9_.-]+$")
    password: str = Field(min_length=12, max_length=256)
    role: str = Field(pattern="^(" + "|".join(ROLES) + ")$")


class UserOut(BaseModel):
    id: int
    username: str
    role: str
    is_active: bool


class MeOut(BaseModel):
    username: str
    role: str
