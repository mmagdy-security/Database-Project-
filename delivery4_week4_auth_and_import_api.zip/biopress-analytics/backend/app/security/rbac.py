"""Role model: admin > analyst > viewer. Pure functions, no framework."""
from app.db.constants import ROLE_RANK


def has_role(actual: str, required: str) -> bool:
    return ROLE_RANK.get(actual, 0) >= ROLE_RANK[required]
