"""Short-lived JWT access tokens (HS256). The algorithm is pinned: tokens with alg=none or another alg are rejected."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

import jwt

from app.config import Settings
from app.db.constants import ROLES

ALGORITHM = "HS256"


class TokenError(Exception):
    pass


@dataclass(frozen=True)
class Principal:
    username: str
    role: str
    user_id: int | None = None


def create_access_token(*, username: str, role: str, user_id: int | None, settings: Settings,
                        now: datetime | None = None) -> str:
    if role not in ROLES:
        raise ValueError(f"unknown role {role!r}")
    now = now or datetime.now(timezone.utc)
    claims = {"sub": username, "role": role, "uid": user_id, "iat": now,
              "exp": now + timedelta(minutes=settings.access_token_minutes)}
    return jwt.encode(claims, settings.require_secret_key(), algorithm=ALGORITHM)


def decode_access_token(token: str, settings: Settings) -> Principal:
    try:
        claims = jwt.decode(token, settings.require_secret_key(), algorithms=[ALGORITHM],
                            options={"require": ["exp", "iat", "sub", "role"]})
    except jwt.PyJWTError as exc:
        raise TokenError(str(exc)) from exc
    if claims["role"] not in ROLES:
        raise TokenError("unknown role")
    return Principal(username=claims["sub"], role=claims["role"], user_id=claims.get("uid"))
