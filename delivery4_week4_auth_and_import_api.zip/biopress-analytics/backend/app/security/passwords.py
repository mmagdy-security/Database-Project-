"""Password hashing with argon2id (argon2-cffi). No default accounts exist anywhere in the repository."""
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError

MIN_LENGTH = 12
_ph = PasswordHasher()
# Verified when the username is unknown, so response time does not reveal which usernames exist.
DUMMY_HASH = _ph.hash("not-a-real-password-for-timing-only")


def check_strength(password: str) -> None:
    if len(password) < MIN_LENGTH:
        raise ValueError(f"Password must be at least {MIN_LENGTH} characters.")


def hash_password(password: str) -> str:
    check_strength(password)
    return _ph.hash(password)


def verify_password(password_hash: str, password: str) -> bool:
    try:
        return _ph.verify(password_hash, password)
    except (VerificationError, InvalidHashError):
        return False
