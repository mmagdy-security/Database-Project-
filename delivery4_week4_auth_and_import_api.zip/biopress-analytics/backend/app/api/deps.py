"""Authentication, authorization and rate-limit dependencies (shared by every router).

- get_principal      : validates the bearer token (stateless, 15-minute tokens).
- require_role(r)    : principal must have at least role r.
- require_fresh_role : same, but re-reads the user from the database (disabled/demoted users lose
                       access immediately). Used for admin actions.
- read_access        : analytics reads. Enforces `viewer` unless REQUIRE_AUTH=false (dev/CSV only;
                       the setting is rejected in production).
"""
from __future__ import annotations

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db.models import User
from app.db.session import get_session
from app.security.rbac import has_role
from app.security.ratelimit import SlidingWindowLimiter
from app.security.tokens import Principal, TokenError, decode_access_token

bearer = HTTPBearer(auto_error=False)
login_limiter = SlidingWindowLimiter(max_events=10, window_seconds=60)       # per IP and per username
import_limiter = SlidingWindowLimiter(max_events=10, window_seconds=3600)    # per user


def _unauthorized(detail: str = "Not authenticated") -> HTTPException:
    return HTTPException(status.HTTP_401_UNAUTHORIZED, detail, headers={"WWW-Authenticate": "Bearer"})


def client_ip(request: Request) -> str | None:
    # Behind a reverse proxy, configure the proxy/uvicorn --proxy-headers with trusted hosts; do not trust X-Forwarded-For here.
    return request.client.host if request.client else None


def get_principal(creds: HTTPAuthorizationCredentials | None = Depends(bearer)) -> Principal:
    if creds is None or creds.scheme.lower() != "bearer":
        raise _unauthorized()
    try:
        return decode_access_token(creds.credentials, get_settings())
    except TokenError:
        raise _unauthorized("Invalid or expired token")


def require_role(minimum: str):
    def dependency(principal: Principal = Depends(get_principal)) -> Principal:
        if not has_role(principal.role, minimum):
            raise HTTPException(status.HTTP_403_FORBIDDEN, f"Requires role '{minimum}' or higher")
        return principal
    return dependency


def require_fresh_role(minimum: str):
    def dependency(principal: Principal = Depends(require_role(minimum)),
                   session: Session = Depends(get_session)) -> Principal:
        user = session.scalar(select(User).where(User.username == principal.username))
        if user is None or not user.is_active:
            raise _unauthorized("Account disabled or unknown")
        if not has_role(user.role, minimum):
            raise HTTPException(status.HTTP_403_FORBIDDEN, f"Requires role '{minimum}' or higher")
        return Principal(username=user.username, role=user.role, user_id=user.id)
    return dependency


def read_access(creds: HTTPAuthorizationCredentials | None = Depends(bearer)) -> Principal | None:
    if not get_settings().require_auth:
        return None
    principal = get_principal(creds)
    if not has_role(principal.role, "viewer"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Forbidden")
    return principal


def rate_limit(limiter: SlidingWindowLimiter, key_prefix: str):
    def dependency(request: Request) -> None:
        if not limiter.allow(f"{key_prefix}:{client_ip(request)}"):
            raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, "Too many requests", headers={"Retry-After": "60"})
    return dependency
