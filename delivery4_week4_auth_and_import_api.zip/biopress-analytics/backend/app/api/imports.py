"""CSV import endpoints (admin only): preview first, then confirm with the file's SHA-256.

Nothing is written by /preview. /confirm re-validates the same bytes, refuses if the hash differs
from the previewed one, stores the raw file read-only, and writes everything in ONE transaction.
"""
from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.api.deps import client_ip, import_limiter, rate_limit, require_fresh_role
from app.config import get_settings
from app.db.models import DataImport
from app.db.session import get_session
from app.schemas.imports import ImportCommitOut, ImportPreviewOut
from app.security.tokens import Principal
from app.services import audit
from app.services.import_service import (DuplicateImportError, commit_import, find_import_by_sha,
                                         store_raw_upload)
from app.services.importer import parse_and_validate

router = APIRouter(prefix="/api/v1/imports", tags=["imports"])


async def _read(file: UploadFile):
    s = get_settings()
    raw = await file.read(s.max_upload_bytes + 1)      # never read more than limit + 1 byte
    return raw, parse_and_validate(raw, file.filename or "", max_bytes=s.max_upload_bytes, max_rows=s.max_rows)


@router.post("/preview", response_model=ImportPreviewOut, dependencies=[Depends(rate_limit(import_limiter, "import"))])
async def preview(request: Request, file: UploadFile = File(...),
                  admin: Principal = Depends(require_fresh_role("admin")), session: Session = Depends(get_session)):
    _, report = await _read(file)
    exists = bool(report.sha256) and find_import_by_sha(session, report.sha256) is not None
    audit.record(session, "import_preview", user_id=admin.user_id, username=admin.username,
                 resource=report.sha256 or None, ip=client_ip(request),
                 details={"filename": report.filename[:255], "ok": report.ok, "rows": report.row_count,
                          "errors": [e.code for e in report.errors], "warnings": [w.code for w in report.warnings]})
    session.commit()
    return {**report.to_dict(), "already_imported": exists, "can_confirm": report.ok and not exists}


@router.post("/confirm", response_model=ImportCommitOut, status_code=status.HTTP_201_CREATED,
             dependencies=[Depends(rate_limit(import_limiter, "import"))])
async def confirm(request: Request, file: UploadFile = File(...), expected_sha256: str = Form(...),
                  admin: Principal = Depends(require_fresh_role("admin")), session: Session = Depends(get_session)):
    raw, report = await _read(file)
    if report.sha256 != expected_sha256.strip().lower():
        raise HTTPException(status.HTTP_409_CONFLICT, "The file differs from the one that was previewed.")
    if not report.ok:
        audit.record(session, "import_rejected", user_id=admin.user_id, username=admin.username,
                     resource=report.sha256, ip=client_ip(request), details={"errors": [e.code for e in report.errors]})
        session.commit()
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, detail=report.to_dict(preview_rows=0))
    store_raw_upload(raw, report.sha256, get_settings().upload_dir)
    try:
        imp = commit_import(session, report, imported_by=admin.user_id)
        audit.record(session, "import_confirm", user_id=admin.user_id, username=admin.username,
                     resource=f"import:{imp.id}", ip=client_ip(request),
                     details={"sha256": report.sha256, "rows": imp.row_count, "warnings": [w.code for w in report.warnings]})
        session.commit()                                  # data_imports + rows + audit: one transaction
    except (DuplicateImportError, IntegrityError):
        session.rollback()
        raise HTTPException(status.HTTP_409_CONFLICT, "This file was already imported.")
    return ImportCommitOut(import_id=imp.id, sha256=imp.sha256, row_count=imp.row_count,
                           complied_yes=report.complied_yes, warnings=[w.to_dict() for w in report.warnings])


@router.get("")
def list_imports(admin: Principal = Depends(require_fresh_role("admin")), session: Session = Depends(get_session)):
    return [{"id": i.id, "filename": i.filename, "sha256": i.sha256, "row_count": i.row_count,
             "status": i.status, "imported_at": i.imported_at.isoformat() if i.imported_at else None}
            for i in session.scalars(select(DataImport).order_by(DataImport.id))]
