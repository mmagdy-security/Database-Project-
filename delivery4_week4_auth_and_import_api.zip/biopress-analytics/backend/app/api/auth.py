from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import client_ip, get_principal, login_limiter, require_fresh_role
from app.config import get_settings
from app.db.models import User
from app.db.session import get_session
from app.schemas.auth import LoginIn, MeOut, TokenOut, UserCreate, UserOut
from app.security.passwords import DUMMY_HASH, hash_password, verify_password
from app.security.tokens import Principal, create_access_token
from app.services import audit

router = APIRouter(prefix="/api/v1", tags=["auth"])


@router.post("/auth/login", response_model=TokenOut)
def login(body: LoginIn, request: Request, session: Session = Depends(get_session)):
    ip = client_ip(request)
    if not (login_limiter.allow(f"ip:{ip}") and login_limiter.allow(f"user:{body.username.lower()}")):
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, "Too many login attempts", headers={"Retry-After": "60"})
    user = session.scalar(select(User).where(User.username == body.username))
    password_ok = verify_password(user.password_hash if user else DUMMY_HASH, body.password)
    if user is None or not user.is_active or not password_ok:
        audit.record(session, "login_failed", username=body.username[:64], ip=ip)
        session.commit()
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect username or password",
                            headers={"WWW-Authenticate": "Bearer"})
    settings = get_settings()
    token = create_access_token(username=user.username, role=user.role, user_id=user.id, settings=settings)
    audit.record(session, "login_ok", user_id=user.id, username=user.username, ip=ip)
    session.commit()
    return TokenOut(access_token=token, expires_in=settings.access_token_minutes * 60)


@router.get("/auth/me", response_model=MeOut)
def me(principal: Principal = Depends(get_principal)):
    return MeOut(username=principal.username, role=principal.role)


@router.post("/admin/users", response_model=UserOut, status_code=201)
def create_user(body: UserCreate, request: Request, admin: Principal = Depends(require_fresh_role("admin")),
                session: Session = Depends(get_session)):
    if session.scalar(select(User.id).where(User.username == body.username)) is not None:
        raise HTTPException(status.HTTP_409_CONFLICT, "Username already exists")
    user = User(username=body.username, role=body.role, password_hash=hash_password(body.password))
    session.add(user)
    session.flush()
    audit.record(session, "user_create", user_id=admin.user_id, username=admin.username,
                 resource=f"user:{user.id}", details={"new_username": user.username, "role": user.role},
                 ip=client_ip(request))
    session.commit()
    return UserOut(id=user.id, username=user.username, role=user.role, is_active=user.is_active)


@router.get("/admin/users", response_model=list[UserOut])
def list_users(admin: Principal = Depends(require_fresh_role("admin")), session: Session = Depends(get_session)):
    return [UserOut(id=u.id, username=u.username, role=u.role, is_active=u.is_active)
            for u in session.scalars(select(User).order_by(User.id))]
