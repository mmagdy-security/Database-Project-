from datetime import datetime, timedelta, timezone

import jwt
import pytest

from app.config import ConfigError, Settings
from app.security.ratelimit import SlidingWindowLimiter
from app.security.rbac import has_role
from app.security.tokens import TokenError, create_access_token, decode_access_token

S = Settings(secret_key="k" * 40, access_token_minutes=15)


def test_token_roundtrip():
    t = create_access_token(username="amal", role="analyst", user_id=7, settings=S)
    p = decode_access_token(t, S)
    assert (p.username, p.role, p.user_id) == ("amal", "analyst", 7)


def test_expired_token_is_rejected():
    old = datetime.now(timezone.utc) - timedelta(hours=1)
    t = create_access_token(username="a", role="viewer", user_id=1, settings=S, now=old)
    with pytest.raises(TokenError):
        decode_access_token(t, S)


def test_wrong_key_and_tampering_are_rejected():
    t = create_access_token(username="a", role="viewer", user_id=1, settings=S)
    with pytest.raises(TokenError):
        decode_access_token(t, Settings(secret_key="z" * 40))
    with pytest.raises(TokenError):
        decode_access_token(t[:-3] + ("AAA" if not t.endswith("AAA") else "BBB"), S)


def test_alg_none_and_role_escalation_are_rejected():
    now = datetime.now(timezone.utc)
    claims = {"sub": "a", "role": "admin", "iat": now, "exp": now + timedelta(minutes=5)}
    with pytest.raises(TokenError):
        decode_access_token(jwt.encode(claims, key=None, algorithm="none"), S)
    with pytest.raises(TokenError):
        decode_access_token(jwt.encode({**claims, "role": "root"}, S.secret_key, algorithm="HS256"), S)
    with pytest.raises(TokenError):
        decode_access_token(jwt.encode({k: v for k, v in claims.items() if k != "exp"}, S.secret_key, algorithm="HS256"), S)


def test_weak_or_missing_secret_key_is_refused():
    for bad in ("", "change-me", "short"):
        with pytest.raises(ConfigError):
            create_access_token(username="a", role="viewer", user_id=1, settings=Settings(secret_key=bad))


def test_role_hierarchy():
    assert has_role("admin", "viewer") and has_role("admin", "admin") and has_role("analyst", "viewer")
    assert not has_role("viewer", "analyst") and not has_role("viewer", "admin") and not has_role("analyst", "admin")
    assert not has_role("unknown", "viewer")


def test_rate_limiter_blocks_then_recovers():
    now = [0.0]
    lim = SlidingWindowLimiter(3, 60, clock=lambda: now[0])
    assert [lim.allow("ip") for _ in range(4)] == [True, True, True, False]
    assert lim.allow("other")                           # keys are independent
    now[0] = 61
    assert lim.allow("ip")


def test_production_refuses_unsafe_settings():
    with pytest.raises(ConfigError):
        Settings(env="production", data_source="db", database_url="x", require_auth=False).validate()
    with pytest.raises(ConfigError):
        Settings(env="production", data_source="csv", require_auth=True).validate()
    with pytest.raises(ConfigError):
        Settings(data_source="db", database_url="").validate()
