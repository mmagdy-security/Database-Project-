# Architecture (Database & Security view)

Owner of this document's database and security sections: Database & Security team.
The API and ML sections are completed by the other teams.

## 1. Data flow

```
raw CSV (read-only, data/raw)  ──►  importer (validate, warn)  ──►  PostgreSQL  ──►  views  ──►  API  ──►  dashboard
 uploaded CSV (data/uploads, read-only copy, named by SHA-256) ─┘                    │
                                                                                     ├─ v_ml_features      → AI team (5 columns only)
                                                                                     ├─ v_compliance_facts → analytics/API
                                                                                     └─ v_import_summary   → agents/auditors
```

## 2. ERD

Only what the data supports. There are **no** tables for dates, workers, patients or sessions: the data has none, and we do not invent them.

```mermaid
erDiagram
    institutions ||--o{ wards : has
    wards ||--o{ hand_hygiene_opportunities : "observed in"
    data_imports ||--o{ hand_hygiene_opportunities : contains
    users |o--o{ data_imports : imported_by
    users |o--o{ audit_log : actor
    data_imports |o--o{ model_runs : "trained on"

    institutions { int id PK  string name UK }
    wards { int id PK  int institution_id FK  string name }
    users { int id PK  string username UK  string role  string password_hash  bool is_active  datetime created_at }
    data_imports { int id PK  string filename  string sha256 UK  int row_count  string status  int imported_by FK  datetime imported_at  text notes }
    hand_hygiene_opportunities {
        int id PK
        int import_id FK
        int row_number "unique with import_id"
        int source_opp "original Opp, NOT unique (788 twice)"
        int ward_id FK
        string profcat "CHECK allowed list"
        string shift "CHECK allowed list"
        string indication "CHECK allowed list"
        string hh_action "nullable, LEAKY"
        string missed_but_glove "nullable, LEAKY"
        bool complied "NOT NULL"
    }
    model_runs { int id PK  datetime created_at  string model_type  string git_commit  int data_import_id FK  json features  json metrics  string artifact_path }
    audit_log { int id PK  datetime ts  int user_id FK  string username  string action  string resource  json details  string ip }
```

Design decisions

| Decision | Reason |
|---|---|
| Unique key is `(import_id, row_number)`; `source_opp` is stored as-is | Opp 788 appears twice and 787 is missing. Opp is a sequence number, not an identifier. |
| `profcat`, `shift`, `indication`: text with `CHECK` against the allowed list; ward through the `wards` lookup table | Unknown categories are rejected at import and reported, and cannot be inserted by any other path. |
| `complied` is `NOT NULL` (+ explicit CHECK) | The target must always be known. |
| `data_imports.sha256` is `UNIQUE` | Ties every analysis to an exact file and stops double imports. |
| `status` (`committed` / `archived`); views show only `committed` | A bad import is archived, never deleted. |
| Indexes: `import_id`, `ward_id`, `indication`, `shift` | Filters used by the dashboard. |
| `hh_action` and `missed_but_glove` are stored but only reachable from the table, never from a view | They are kept for the audit (descriptive use among non-compliant staff), and cannot leak into a model by accident. |

Views (`backend/app/db/sql_views.py`, created by migration `0002`)

| View | Columns | Reader |
|---|---|---|
| `v_ml_features` | `ward, profcat, shift, indication, complied` | AI team (training data only from here) |
| `v_compliance_facts` | `ward, shift, profcat, indication, n, complied_count` | API / analytics |
| `v_import_summary` | `id, filename, sha256, row_count, status, imported_at, notes` (warnings as JSON) | agents, auditors (no uploader identity) |

## 3. Import pipeline

1. Only `.csv`, at most `MAX_UPLOAD_BYTES` (5 MB) and `MAX_ROWS` (20 000).
2. Validate required columns, exact allowed values (no trimming, no "fixes"), types. **Unexpected columns are rejected**, not stored (data minimisation).
3. Data-contract checks, reported as warnings and stored in `data_imports.notes`: duplicated `Opp`, `Opp` gaps, `HHaction` empty exactly when `Complied = No`, `Missedbutglove` empty exactly when `Complied = Yes`, missing `Opp`.
4. `POST /api/v1/imports/preview` shows the report and writes nothing.
5. `POST /api/v1/imports/confirm` re-validates the same bytes, refuses if the SHA-256 differs from the previewed one, then writes `data_imports`, all rows and the audit entry **in one transaction**.
6. The uploaded bytes are stored unchanged and read-only as `data/uploads/<sha256>.csv`. Cleaning, if ever needed, happens in processed copies.

Result for the original file: 917 rows, 202 complied (22.0%), warnings `duplicate_source_opp [788]` and `missing_source_opp_in_sequence [787]`, no target-dependence violation.

## 4. Security

### 4.1 Access control

| Role | Can |
|---|---|
| `viewer` | read dashboards and analytics endpoints |
| `analyst` | everything a viewer can + export summaries |
| `admin` | everything + imports, user management, training |

- Short-lived JWT access tokens (15 minutes, HS256, algorithm pinned, `exp/iat/sub/role` required). Passwords hashed with argon2id, minimum 12 characters. **No default accounts**: the first admin is created with `scripts/create_admin.py`.
- Analytics reads need a valid token (`REQUIRE_AUTH=true`; `false` is refused in production). Export, import, user and training endpoints are **always** protected.
- Admin endpoints re-read the user from the database on every call, so a disabled or demoted admin loses access immediately instead of after the token expires. Read endpoints use the token claims only (maximum delay: 15 minutes).
- `POST /api/v1/ml/train` is registered only when `APP_ENV=development`; elsewhere the route does not exist.

### 4.2 Database roles (least privilege)

| Role | Used by | Privileges |
|---|---|---|
| `migration_owner` | Alembic only | owns the schema objects |
| `app_rw` | the API | `SELECT/INSERT/UPDATE` on `users`, `data_imports`; `SELECT/INSERT` on `hand_hygiene_opportunities`, `model_runs`; `SELECT` on lookups and views; **`INSERT` only on `audit_log`**. No `DELETE` anywhere, no `UPDATE` on imported rows. |
| `analytics_ro` | analysts, notebooks | `SELECT` on the three views only |
| `agent_ro` | the optional agent | `SELECT` on `v_compliance_facts` and `v_import_summary` only (aggregates, no row-level data) |

Grants are explicit per table (no `ALTER DEFAULT PRIVILEGES`), so a new table is private until someone grants it on purpose.

### 4.3 Secrets and configuration
- Secrets only in environment variables. `.env` is git-ignored; `.env.example` holds placeholders. There is no default for `SECRET_KEY` or any password; the app refuses to start/sign tokens with a missing, placeholder or short (<32) key. `docker compose` fails if a password is not set.
- gitleaks runs in the pre-commit hook and in CI over the full git history.

### 4.4 Input and output safety
- Only ORM / bound parameters; no string-built SQL with user input (the only SQL strings are the fixed views and one fixed `SELECT`).
- Request bodies are validated with Pydantic (field lengths, role list, username pattern). Group/filter parameters added later must be checked against `app/db/constants.py` (the single list of allowed values).
- CSV exports neutralise cells starting with `=`, `+`, `-`, `@`, tab or CR (a leading `'`), and contain aggregates only.
- CORS limited to `CORS_ORIGINS`; rate limits on login (10/min per IP and per username) and imports (10/hour per IP); security headers (`nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy`, `Content-Security-Policy`, `Cache-Control: no-store`, HSTS in production). HTTPS is terminated by the reverse proxy in any deployed environment.

### 4.5 Privacy and data minimisation
- The data holds no personal identifiers and the importer keeps it that way (unexpected columns are rejected).
- Exports withhold rate and confidence interval when n < 5 and flag groups with n < 30 (`sample_flag`). n is always shown.
- Nothing in the database or the exports identifies or ranks individual staff.
- Real hospital data needs documented permission and institutional/ethics approval before it enters the system.

### 4.6 Logging and recovery
- `audit_log` (append-only for the API role) records logins (success and failure), import previews/confirmations/rejections, exports, user creation, training and, later, model runs and agent tool calls. It never stores passwords, tokens or file contents.
- `scripts/backup.sh`: nightly `pg_dump -Fc`, mode 700 directory, SHA-256 file, 14-day retention. `scripts/restore_test.sh`: restores into a throw-away database and checks 917 / 202.

## 5. Known limits (stated on purpose)
- Rate limiting is in memory: correct for one API process. For several workers use the proxy or Redis.
- Read endpoints trust the token for up to 15 minutes.
- The system was designed for one hospital's audit file; it makes no claim about other hospitals.
