# Security review checklist (final sign-off, week 10)

Tick each line only after you have run the check. "Evidence" = command or test.

## Definition of done (from the team plan)
- [ ] Importing the original file creates 917 rows; summary returns 202 / 917 — `test_api_security.py::test_import_original_file_then_summary_is_917_202`, `scripts/seed_from_csv.py`
- [ ] File with a missing column / unknown `Complied` is rejected with a clear message — `test_importer.py`, `test_api_security.py::test_bad_files_are_rejected_with_clear_messages`
- [ ] Viewer token cannot call import, train or user endpoints — `test_api_security.py::test_viewer_*`
- [ ] `v_ml_features` has no `HHaction` / `Missedbutglove` — `test_views_sql.py`, `test_db_orm.py::test_ml_view_columns_exclude_leaky_columns`
- [ ] No secret in repository history — `gitleaks detect --source . --log-opts="--all"` and the CI job `secrets`

## Access control
- [ ] No default accounts in the repo (`grep -ri "password" --include=*.py --include=*.sql .` shows no literal passwords)
- [ ] First admin created with `scripts/create_admin.py`
- [ ] `APP_ENV=production` refuses `REQUIRE_AUTH=false` and `DATA_SOURCE=csv` — `test_tokens_rbac.py::test_production_refuses_unsafe_settings`
- [ ] `/api/v1/ml/train` returns 404 outside development
- [ ] `app_rw` cannot DELETE / UPDATE imported rows, cannot read `audit_log`: `docker compose exec db psql -U app_rw -d biopress -c "DELETE FROM hand_hygiene_opportunities"` must fail
- [ ] `analytics_ro` and `agent_ro` cannot read base tables: `SELECT * FROM hand_hygiene_opportunities` must fail
- [ ] `agent_ro` cannot read `v_ml_features`

## Secrets
- [ ] `.env` is not tracked (`git ls-files | grep -x .env` is empty); `.env.example` has placeholders only
- [ ] `SECRET_KEY` is random, >= 32 chars, different per environment
- [ ] pre-commit hook installed on every laptop (`pre-commit install`)

## Input / output
- [ ] Upload limits work (5 MB, 20 000 rows, `.csv` only)
- [ ] Export neutralises formula cells — `test_export_safety.py`
- [ ] CORS origin list contains only the real frontend origin
- [ ] Security headers present — `test_api_security.py::test_security_headers_present`
- [ ] HTTPS terminated in front of the API in any deployed environment (HSTS is sent only when `APP_ENV=production`)
- [ ] If the frontend keeps the token: in memory, never `localStorage` (Web team)

## Privacy
- [ ] Importer rejects unexpected columns — `test_importer.py::test_unexpected_column_is_rejected_not_stored`
- [ ] Rates withheld for n < 5, flagged for n < 30 — `test_export_safety.py`
- [ ] No endpoint or export ranks or lists individual staff
- [ ] `model_card.md` privacy and misuse statements reviewed (AI team hands it to this team)
- [ ] Written permission / ethics approval on file before any real hospital data beyond the published audit file

## Logging and recovery
- [ ] `audit_log` has entries for login, import, export, user creation
- [ ] Nightly backup scheduled (cron line in `scripts/backup.sh`)
- [ ] **Restore test passed on a fresh machine/volume**: `./scripts/backup.sh && ./scripts/restore_test.sh backups/<file>.dump` prints `RESTORE TEST PASSED`
- [ ] Backup directory is outside the repo or git-ignored, mode 700

## Known limits to repeat in the final report
- In-memory rate limiter (single process only)
- Read tokens valid up to 15 minutes after a role change
- One hospital, 2017, observational data
