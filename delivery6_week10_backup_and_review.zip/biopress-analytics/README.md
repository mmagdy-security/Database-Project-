# BIOPRESS Analytics (Phase 1 starter)

Software-only analytics for hand hygiene compliance audit data.

## Run (database mode)
```bash
cp .env.example .env              # edit passwords + SECRET_KEY (python -c "import secrets; print(secrets.token_urlsafe(48))")
docker compose up -d db           # PostgreSQL 16 + least-privilege roles
cd backend
pip install -r requirements.txt
alembic upgrade head              # schema, views, grants (MIGRATION_DATABASE_URL from .env)
python ../scripts/seed_from_csv.py        # imports the original file: 917 rows / 202 complied
python ../scripts/create_admin.py <your-username>
python -m pytest -q
uvicorn app.main:app --reload
```
Quick CSV-only mode (no database, no login): `DATA_SOURCE=csv REQUIRE_AUTH=false uvicorn app.main:app --reload`.
Backups: `scripts/backup.sh`, restore check: `scripts/restore_test.sh <dump>`. Security review: `docs/security_checklist.md`.
Endpoints: `/health`, `/api/v1/analytics/summary`, `/api/v1/analytics/by-{ward,shift,indication,profcat}`.
Docs UI: http://127.0.0.1:8000/docs

## Status
- [x] Data audit and dictionary (`docs/`)
- [x] Descriptive analytics API with n, Wilson CI and chi-square test per dimension
- [x] Database (PostgreSQL), CSV import with preview/confirm, views, roles, auth, audit log, export safety (Database & Security team)
- [ ] Dashboard
- [ ] ML evaluation (LogReg vs Dummy; allowed features only)
- [ ] XAI, reports, model_card

Raw data in `data/raw/` is read-only. Never commit patient-level or confidential data to a public repo.
