#!/usr/bin/env bash
# Restore test: restores a backup into a THROWAWAY database and checks the audit numbers (917 / 202).
# Never touches the live database. Run before the final demo and after every backup-policy change.
#   ./scripts/restore_test.sh backups/biopress_<stamp>.dump
set -euo pipefail
cd "$(dirname "$0")/.."
dump="${1:?usage: restore_test.sh <backup.dump>}"
[ -f "$dump.sha256" ] && sha256sum -c "$dump.sha256"
tmpdb="biopress_restore_test"
psql_admin() { docker compose exec -T db sh -c "psql -v ON_ERROR_STOP=1 -U \"\$POSTGRES_USER\" -d postgres $*"; }
psql_admin "-c 'DROP DATABASE IF EXISTS $tmpdb'"
psql_admin "-c 'CREATE DATABASE $tmpdb'"
trap "psql_admin \"-c 'DROP DATABASE IF EXISTS $tmpdb'\"" EXIT
docker compose exec -T db sh -c "pg_restore -U \"\$POSTGRES_USER\" -d $tmpdb --no-owner --no-privileges" < "$dump"
result="$(docker compose exec -T db sh -c "psql -tA -U \"\$POSTGRES_USER\" -d $tmpdb -c \"SELECT count(*) || '/' || sum(complied::int) FROM v_ml_features\"" | tr -d '[:space:]')"
echo "Restored view v_ml_features: rows/complied = $result"
[ "$result" = "917/202" ] && echo "RESTORE TEST PASSED" || { echo "RESTORE TEST FAILED (expected 917/202)"; exit 1; }
