#!/usr/bin/env bash
# Nightly logical backup of the BIOPRESS database (custom format, restorable with pg_restore).
#   ./scripts/backup.sh                       # uses docker compose service "db"
# Cron (02:30 every night):  30 2 * * *  cd /path/to/biopress-analytics && ./scripts/backup.sh >> backups/backup.log 2>&1
# BACKUP_DIR must be outside the repository or git-ignored (backups/ is ignored) and protected (chmod 700).
set -euo pipefail
cd "$(dirname "$0")/.."
BACKUP_DIR="${BACKUP_DIR:-backups}"
RETENTION_DAYS="${RETENTION_DAYS:-14}"
umask 077
mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"
stamp="$(date -u +%Y%m%dT%H%M%SZ)"
out="$BACKUP_DIR/biopress_${stamp}.dump"
docker compose exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > "$out"
[ -s "$out" ] || { echo "Backup is empty, failing"; rm -f "$out"; exit 1; }
sha256sum "$out" > "$out.sha256"
find "$BACKUP_DIR" -name 'biopress_*.dump*' -mtime +"$RETENTION_DAYS" -delete
echo "Backup written: $out"
