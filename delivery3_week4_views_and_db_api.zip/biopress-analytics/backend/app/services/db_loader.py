"""Analysis frame from PostgreSQL, through the v_ml_features view only.

The view exposes five columns, so HHaction / Missedbutglove / Opp cannot be reached from here.
The columns are renamed to the names analytics.py already expects (Ward, Profcat, Shift, Indication, complied).
"""
import pandas as pd
from sqlalchemy import text

from app.db.session import get_engine


class NoDataError(RuntimeError):
    pass


def load_frame_from_db() -> pd.DataFrame:
    with get_engine().connect() as conn:
        df = pd.read_sql(text("SELECT ward, profcat, shift, indication, complied FROM v_ml_features"), conn)
    if df.empty:
        raise NoDataError("No data has been imported yet.")
    df = df.rename(columns={"ward": "Ward", "profcat": "Profcat", "shift": "Shift", "indication": "Indication"})
    df["complied"] = df["complied"].astype(int)
    return df
