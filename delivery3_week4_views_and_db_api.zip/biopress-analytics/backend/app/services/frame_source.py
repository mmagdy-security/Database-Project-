"""Chooses where the API reads its data: the database (default) or the raw CSV (legacy / quick tests)."""
import pandas as pd

from app.config import get_settings
from app.services import data_loader, db_loader
from app.services.db_loader import NoDataError  # noqa: F401  (re-exported for main.py)


def get_frame() -> pd.DataFrame:
    if get_settings().data_source == "db":
        return db_loader.load_frame_from_db()
    return data_loader.get_frame()
