"""SQL for the analytics views. Portable (PostgreSQL and SQLite) so tests can run on both.

v_ml_features      : the ONLY thing the AI team reads. Exactly five columns; no HHaction,
                     Missedbutglove, source_opp, row_number or import id.
v_compliance_facts : counts per ward x shift x profcat x indication for analytics/API.
v_import_summary   : import metadata for agents/auditors (no uploader identity).

Only rows from imports with status 'committed' are visible, so archiving an import
removes it from every analysis without deleting anything.
"""

V_ML_FEATURES = """
CREATE VIEW v_ml_features AS
SELECT w.name AS ward,
       o.profcat AS profcat,
       o.shift AS shift,
       o.indication AS indication,
       o.complied AS complied
FROM hand_hygiene_opportunities o
JOIN wards w ON w.id = o.ward_id
JOIN data_imports i ON i.id = o.import_id
WHERE i.status = 'committed'
"""

V_COMPLIANCE_FACTS = """
CREATE VIEW v_compliance_facts AS
SELECT w.name AS ward,
       o.shift AS shift,
       o.profcat AS profcat,
       o.indication AS indication,
       COUNT(*) AS n,
       SUM(CASE WHEN o.complied THEN 1 ELSE 0 END) AS complied_count
FROM hand_hygiene_opportunities o
JOIN wards w ON w.id = o.ward_id
JOIN data_imports i ON i.id = o.import_id
WHERE i.status = 'committed'
GROUP BY w.name, o.shift, o.profcat, o.indication
"""

V_IMPORT_SUMMARY = """
CREATE VIEW v_import_summary AS
SELECT id, filename, sha256, row_count, status, imported_at, notes
FROM data_imports
"""

VIEWS = {
    "v_ml_features": V_ML_FEATURES,
    "v_compliance_facts": V_COMPLIANCE_FACTS,
    "v_import_summary": V_IMPORT_SUMMARY,
}
ML_FEATURE_COLUMNS = ("ward", "profcat", "shift", "indication", "complied")
