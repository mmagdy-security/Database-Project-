from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from app.schemas.analytics import GroupAnalysis, Summary
from app.services import analytics
from app.services.frame_source import NoDataError, get_frame

app = FastAPI(title="BIOPRESS Analytics", version="0.2.0")


@app.exception_handler(NoDataError)
async def no_data_handler(request: Request, exc: NoDataError):
    return JSONResponse(status_code=503, content={"detail": str(exc)})


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/api/v1/analytics/summary", response_model=Summary)
def get_summary():
    return analytics.summary(get_frame())


def _group_endpoint(dimension: str):
    def handler():
        return analytics.by_group(get_frame(), dimension)
    return handler


for _dim, _path in [("ward", "by-ward"), ("shift", "by-shift"), ("indication", "by-indication"), ("profcat", "by-profcat")]:
    app.add_api_route(f"/api/v1/analytics/{_path}", _group_endpoint(_dim), methods=["GET"], response_model=GroupAnalysis)
