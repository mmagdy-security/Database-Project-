"""Models, constraints, views and import service on a real (SQLite file) database through SQLAlchemy."""
import pytest

pytest.importorskip("sqlalchemy")

from sqlalchemy import create_engine, func, select, text  # noqa: E402
from sqlalchemy.exc import IntegrityError  # noqa: E402
from sqlalchemy.orm import sessionmaker  # noqa: E402

from app.db.models import Base, DataImport, Opportunity, Ward  # noqa: E402
from app.db.sql_views import ML_FEATURE_COLUMNS, VIEWS  # noqa: E402
from app.services.import_service import (DuplicateImportError, InvalidReportError, commit_import,  # noqa: E402
                                         ensure_reference_data)
from app.services.importer import parse_and_validate  # noqa: E402


@pytest.fixture
def session(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 't.db'}")
    Base.metadata.create_all(engine)
    with engine.begin() as conn:
        for sql in VIEWS.values():
            conn.exec_driver_sql(sql)
    with sessionmaker(bind=engine, expire_on_commit=False)() as s:
        ensure_reference_data(s)
        s.commit()
        yield s


@pytest.fixture
def imported(session, raw_csv_bytes):
    report = parse_and_validate(raw_csv_bytes, "hand_hygiene_data_labeled.csv")
    imp = commit_import(session, report)
    session.commit()
    return imp


def test_reference_data_is_one_institution_and_five_wards(session):
    assert session.scalar(select(func.count()).select_from(Ward)) == 5
    ensure_reference_data(session)                      # idempotent
    assert session.scalar(select(func.count()).select_from(Ward)) == 5


def test_import_creates_917_rows_and_202_complied(session, imported):
    assert imported.row_count == 917
    n, k = session.execute(text("SELECT count(*), sum(complied) FROM v_ml_features")).one()
    assert (n, k) == (917, 202)


def test_import_records_hash_and_warnings(imported, raw_csv_bytes):
    import hashlib
    import json
    assert imported.sha256 == hashlib.sha256(raw_csv_bytes).hexdigest()
    assert {w["code"] for w in json.loads(imported.notes)} == {"duplicate_source_opp", "missing_source_opp_in_sequence"}


def test_same_file_cannot_be_imported_twice(session, imported, raw_csv_bytes):
    with pytest.raises(DuplicateImportError):
        commit_import(session, parse_and_validate(raw_csv_bytes, "again.csv"))


def test_invalid_report_cannot_be_written(session):
    with pytest.raises(InvalidReportError):
        commit_import(session, parse_and_validate(b"Ward\nx\n", "x.csv"))


def test_ml_view_columns_exclude_leaky_columns(session, imported):
    cur = session.execute(text("SELECT * FROM v_ml_features LIMIT 1"))
    assert tuple(cur.keys()) == ML_FEATURE_COLUMNS


def test_source_opp_788_is_not_unique_but_row_number_is(session, imported):
    assert session.scalar(select(func.count()).select_from(Opportunity).where(Opportunity.source_opp == 788)) == 2
    session.add(Opportunity(import_id=imported.id, row_number=1, ward_id=1, profcat="Nurse", shift="Night",
                            indication="After patient contact", complied=True))
    with pytest.raises(IntegrityError):
        session.flush()
    session.rollback()


@pytest.mark.parametrize("field,bad", [("profcat", "Janitor"), ("shift", "Evening"), ("indication", "Whenever"),
                                       ("hh_action", "XX"), ("missed_but_glove", "Maybe")])
def test_check_constraints_reject_unknown_values(session, imported, field, bad):
    good = dict(import_id=imported.id, row_number=99999, ward_id=1, profcat="Nurse", shift="Night",
                indication="After patient contact", complied=True)
    session.add(Opportunity(**{**good, field: bad}))
    with pytest.raises(IntegrityError):
        session.flush()
    session.rollback()


def test_complied_cannot_be_null(session, imported):
    session.add(Opportunity(import_id=imported.id, row_number=99999, ward_id=1, profcat="Nurse", shift="Night",
                            indication="After patient contact", complied=None))
    with pytest.raises(IntegrityError):
        session.flush()
    session.rollback()


def test_archiving_an_import_hides_it_from_views(session, imported):
    imp = session.get(DataImport, imported.id)
    imp.status = "archived"
    session.commit()
    assert session.execute(text("SELECT count(*) FROM v_ml_features")).scalar() == 0
