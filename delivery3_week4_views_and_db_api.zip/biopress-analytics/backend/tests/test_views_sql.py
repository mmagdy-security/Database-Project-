"""The views, tested on plain sqlite3 (no ORM) with the real importer output.

The DDL below mirrors app/db/models.py (columns used by the views). test_db_orm.py checks the real models.
"""
import sqlite3

import pytest

from app.db.constants import WARDS
from app.db.sql_views import ML_FEATURE_COLUMNS, VIEWS
from app.services.importer import parse_and_validate

DDL = """
CREATE TABLE wards (id INTEGER PRIMARY KEY, institution_id INTEGER, name TEXT);
CREATE TABLE data_imports (id INTEGER PRIMARY KEY, filename TEXT, sha256 TEXT UNIQUE, row_count INT,
                           status TEXT, imported_by INT, imported_at TEXT, notes TEXT);
CREATE TABLE hand_hygiene_opportunities (id INTEGER PRIMARY KEY, import_id INT, row_number INT, source_opp INT,
  ward_id INT, profcat TEXT, shift TEXT, indication TEXT, hh_action TEXT, missed_but_glove TEXT, complied BOOLEAN NOT NULL,
  UNIQUE (import_id, row_number));
"""


@pytest.fixture
def db(raw_csv_bytes):
    con = sqlite3.connect(":memory:")
    con.executescript(DDL)
    con.executemany("INSERT INTO wards (id, institution_id, name) VALUES (?, 1, ?)", list(enumerate(WARDS, 1)))
    report = parse_and_validate(raw_csv_bytes, "x.csv")
    con.execute("INSERT INTO data_imports (id, filename, sha256, row_count, status) VALUES (1, 'x.csv', ?, 917, 'committed')", (report.sha256,))
    ward_id = {n: i for i, n in enumerate(WARDS, 1)}
    con.executemany(
        "INSERT INTO hand_hygiene_opportunities (import_id,row_number,source_opp,ward_id,profcat,shift,indication,hh_action,missed_but_glove,complied) VALUES (1,?,?,?,?,?,?,?,?,?)",
        [(r.row_number, r.source_opp, ward_id[r.ward], r.profcat, r.shift, r.indication, r.hh_action, r.missed_but_glove, int(r.complied)) for r in report.rows])
    for sql in VIEWS.values():
        con.execute(sql)
    return con


def test_duplicate_opp_788_is_stored_twice_and_787_is_absent(db):
    assert db.execute("SELECT count(*) FROM hand_hygiene_opportunities WHERE source_opp = 788").fetchone()[0] == 2
    assert db.execute("SELECT count(*) FROM hand_hygiene_opportunities WHERE source_opp = 787").fetchone()[0] == 0


def test_ml_view_has_exactly_the_allowed_columns_and_no_leaky_ones(db):
    cur = db.execute("SELECT * FROM v_ml_features")
    cols = tuple(d[0] for d in cur.description)
    assert cols == ML_FEATURE_COLUMNS == ("ward", "profcat", "shift", "indication", "complied")
    forbidden = {"hh_action", "hhaction", "missed_but_glove", "missedbutglove", "opp", "source_opp", "row_number", "import_id"}
    assert not forbidden & {c.lower() for c in cols}


def test_ml_view_reproduces_917_202_and_22_percent(db):
    n, k = db.execute("SELECT count(*), sum(complied) FROM v_ml_features").fetchone()
    assert (n, k) == (917, 202) and round(100 * k / n, 1) == 22.0


def test_facts_view_totals_match(db):
    n, k = db.execute("SELECT sum(n), sum(complied_count) FROM v_compliance_facts").fetchone()
    assert (n, k) == (917, 202)
    ind = dict(db.execute("SELECT indication, sum(complied_count) FROM v_compliance_facts GROUP BY indication").fetchall())
    assert ind["After body fluid exposure"] == 113          # 113 / 149 = 75.8% in the audit


def test_archived_import_disappears_from_every_view(db):
    db.execute("UPDATE data_imports SET status = 'archived' WHERE id = 1")
    assert db.execute("SELECT count(*) FROM v_ml_features").fetchone()[0] == 0
    assert db.execute("SELECT count(*) FROM v_compliance_facts").fetchone()[0] == 0


def test_import_summary_has_no_uploader_identity(db):
    cols = [d[0] for d in db.execute("SELECT * FROM v_import_summary").description]
    assert "imported_by" not in cols and "notes" in cols
