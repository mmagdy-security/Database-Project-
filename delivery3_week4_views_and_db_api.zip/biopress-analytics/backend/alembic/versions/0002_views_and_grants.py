"""Analytics views and least-privilege grants.

Revision ID: 0002
Revises: 0001

Roles are created by scripts/db/init/01_roles.sh (docker-compose first start).
Grants are explicit per table (no ALTER DEFAULT PRIVILEGES) so a new table is private until
someone consciously grants it. On SQLite only the views are created.
"""
from alembic import op

from app.db.sql_views import VIEWS

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

GRANTS = """
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_rw') THEN
    GRANT USAGE ON SCHEMA public TO app_rw;
    GRANT SELECT ON institutions, wards TO app_rw;
    GRANT SELECT, INSERT, UPDATE ON users TO app_rw;
    GRANT SELECT, INSERT, UPDATE ON data_imports TO app_rw;
    GRANT SELECT, INSERT ON hand_hygiene_opportunities TO app_rw;   -- no UPDATE/DELETE: imported rows are immutable
    GRANT SELECT, INSERT ON model_runs TO app_rw;
    GRANT INSERT ON audit_log TO app_rw;                             -- append-only: cannot read, edit or delete
    GRANT SELECT ON v_ml_features, v_compliance_facts, v_import_summary TO app_rw;
    GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO app_rw;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'analytics_ro') THEN
    GRANT USAGE ON SCHEMA public TO analytics_ro;
    GRANT SELECT ON v_ml_features, v_compliance_facts, v_import_summary TO analytics_ro;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'agent_ro') THEN
    GRANT USAGE ON SCHEMA public TO agent_ro;
    GRANT SELECT ON v_compliance_facts, v_import_summary TO agent_ro;   -- aggregates only, no row-level view
  END IF;
END $$;
"""


def upgrade() -> None:
    for sql in VIEWS.values():
        op.execute(sql)
    if op.get_bind().dialect.name == "postgresql":
        op.execute("REVOKE ALL ON ALL TABLES IN SCHEMA public FROM PUBLIC")
        op.execute(GRANTS)


def downgrade() -> None:
    for name in reversed(list(VIEWS)):
        op.execute(f"DROP VIEW IF EXISTS {name}")
