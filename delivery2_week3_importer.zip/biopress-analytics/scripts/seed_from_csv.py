#!/usr/bin/env python3
"""Import the raw CSV into the database through the SAME validator the API uses.

    cd backend && python ../scripts/seed_from_csv.py [path/to/file.csv]

Uses DATABASE_URL. The raw file is only read, never modified. Safe to re-run: the same file
(same SHA-256) is not imported twice. Expected result for the original file: 917 rows, 202 complied (22.0%).
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

from sqlalchemy.orm import sessionmaker  # noqa: E402

from app.config import get_settings  # noqa: E402
from app.db.session import get_engine  # noqa: E402
from app.services import audit  # noqa: E402
from app.services.import_service import DuplicateImportError, commit_import, store_raw_upload  # noqa: E402
from app.services.importer import parse_and_validate  # noqa: E402


def main(argv: list[str]) -> int:
    path = Path(argv[1]) if len(argv) > 1 else ROOT / "data" / "raw" / "hand_hygiene_data_labeled.csv"
    settings = get_settings()
    raw = path.read_bytes()
    report = parse_and_validate(raw, path.name, max_bytes=settings.max_upload_bytes, max_rows=settings.max_rows)
    for w in report.warnings:
        print(f"WARNING {w.code}: {w.message} count={w.count} examples={w.examples}")
    if not report.ok:
        for e in report.errors:
            print(f"ERROR {e.code}: {e.message} examples={e.examples}")
        return 1
    with sessionmaker(bind=get_engine(), expire_on_commit=False)() as session:
        try:
            store_raw_upload(raw, report.sha256, settings.upload_dir)
            imp = commit_import(session, report)          # wards/institution exist from the Alembic baseline
            audit.record(session, "import_confirm", username="seed_script", resource=f"import:{imp.id}",
                         details={"sha256": report.sha256, "rows": imp.row_count})
            session.commit()
        except DuplicateImportError:
            print("Already imported (same SHA-256). Nothing to do.")
            return 0
    print(f"Imported {len(report.rows)} rows, {report.complied_yes} complied "
          f"({100 * report.complied_yes / len(report.rows):.1f}%). sha256={report.sha256}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
