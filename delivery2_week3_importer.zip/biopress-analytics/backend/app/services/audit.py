"""Append-only audit trail. Never put passwords, tokens or raw file contents in `details`."""
from __future__ import annotations

from sqlalchemy.orm import Session

from app.db.models import AuditLog

ACTIONS = {"login_ok", "login_failed", "import_preview", "import_confirm", "import_rejected",
           "export", "user_create", "model_train", "model_run", "agent_tool_call"}


def record(session: Session, action: str, *, user_id: int | None = None, username: str | None = None,
           resource: str | None = None, details: dict | None = None, ip: str | None = None) -> AuditLog:
    if action not in ACTIONS:
        raise ValueError(f"Unknown audit action {action!r}")
    entry = AuditLog(action=action, user_id=user_id, username=username, resource=resource, details=details, ip=ip)
    session.add(entry)
    session.flush()
    return entry
