"""CSV import validation. Pure Python (stdlib only) so it is easy to test and audit.

Pipeline (docs/architecture.md):
  1. only .csv, size limit, row limit
  2. required columns, allowed values, types      -> ERRORS reject the file
  3. data-contract checks                          -> WARNINGS, reported and stored, never silently fixed
  4. caller shows a preview and asks for confirmation
  5. caller writes inside one transaction (see import_service.py)

Privacy: unexpected columns are rejected, not stored, so personal data cannot slip in.
The raw bytes are never modified; this module only reads them.
"""
from __future__ import annotations

import csv
import hashlib
import io
from dataclasses import dataclass, field

from app.db import constants as c

MAX_EXAMPLES = 20


@dataclass
class Issue:
    code: str
    message: str
    count: int = 0
    examples: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"code": self.code, "message": self.message, "count": self.count, "examples": self.examples}


@dataclass
class ParsedRow:
    row_number: int
    source_opp: int | None
    ward: str
    profcat: str
    shift: str
    indication: str
    hh_action: str | None
    missed_but_glove: str | None
    complied: bool


@dataclass
class ImportReport:
    filename: str
    sha256: str = ""
    size_bytes: int = 0
    row_count: int = 0
    errors: list[Issue] = field(default_factory=list)
    warnings: list[Issue] = field(default_factory=list)
    rows: list[ParsedRow] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors

    @property
    def complied_yes(self) -> int:
        return sum(1 for r in self.rows if r.complied)

    def to_dict(self, preview_rows: int = 10) -> dict:
        n = len(self.rows)
        return {
            "filename": self.filename,
            "sha256": self.sha256,
            "size_bytes": self.size_bytes,
            "row_count": self.row_count,
            "ok": self.ok,
            "complied_yes": self.complied_yes if self.ok else None,
            "complied_no": (n - self.complied_yes) if self.ok else None,
            "errors": [e.to_dict() for e in self.errors],
            "warnings": [w.to_dict() for w in self.warnings],
            "preview": [r.__dict__ for r in self.rows[:preview_rows]] if self.ok else [],
        }


def _add(issues: dict[str, Issue], code: str, message: str, example=None) -> None:
    issue = issues.setdefault(code, Issue(code, message))
    issue.count += 1
    if example is not None and len(issue.examples) < MAX_EXAMPLES and example not in issue.examples:
        issue.examples.append(example)


def parse_and_validate(raw: bytes, filename: str, *, max_bytes: int = 5 * 1024 * 1024, max_rows: int = 20_000) -> ImportReport:
    report = ImportReport(filename=filename, size_bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

    def fail(code: str, message: str, examples=None) -> ImportReport:
        report.errors.append(Issue(code, message, count=1, examples=list(examples or [])))
        return report

    # 1. file-level limits
    if not filename.lower().endswith(".csv"):
        return fail("file_type", "Only .csv files are accepted.")
    if len(raw) > max_bytes:
        return fail("file_too_large", f"File is larger than the limit of {max_bytes} bytes.")
    if not raw.strip():
        return fail("empty_file", "The file is empty.")
    try:
        text = raw.decode("utf-8-sig")   # accepts the BOM that Excel adds
    except UnicodeDecodeError:
        return fail("encoding", "File is not valid UTF-8.")

    # 2a. header
    reader = csv.reader(io.StringIO(text, newline=""))
    try:
        header = next(reader)
    except StopIteration:
        return fail("empty_file", "The file is empty.")
    if len(set(header)) != len(header):
        return fail("duplicate_columns", "The header contains duplicate column names.")
    missing = [col for col in c.REQUIRED_COLUMNS if col not in header]
    extra = [col for col in header if col not in c.REQUIRED_COLUMNS]
    if missing:
        report.errors.append(Issue("missing_columns", f"Required columns are missing: {missing}", len(missing), missing))
    if extra:
        report.errors.append(Issue(
            "unexpected_columns",
            "Unexpected columns are rejected, not stored (data minimisation: the dataset must hold no personal identifiers).",
            len(extra), extra))
    if missing or extra:
        return report
    idx = {name: header.index(name) for name in header}

    # 2b. rows
    errors: dict[str, Issue] = {}
    unknown: dict[str, set] = {}
    opps: list[int] = []
    rows: list[ParsedRow] = []
    n_data = 0
    for line in reader:
        if not any(cell.strip() for cell in line):
            continue                        # fully blank line
        n_data += 1
        if n_data > max_rows:
            return fail("row_limit", f"The file has more than {max_rows} rows.")
        rn = n_data
        if len(line) != len(header):
            _add(errors, "malformed_row", f"Rows must have exactly {len(header)} fields.", rn)
            continue
        v = {name: line[i] for name, i in idx.items()}   # exact values, no trimming (no silent fixes)
        row_ok = True

        for col in ("Ward", "Profcat", "Shift", "Indication", "Complied"):
            if v[col] == "":
                _add(errors, f"missing_value_{col.lower()}", f"Column {col} has empty values.", rn)
                row_ok = False
        for col, allowed in (("Ward", c.WARDS), ("Profcat", c.PROFCATS), ("Shift", c.SHIFTS), ("Indication", c.INDICATIONS)):
            if v[col] != "" and v[col] not in allowed:
                unknown.setdefault(col, set()).add(v[col])
                _add(errors, f"unknown_{col.lower()}", f"Column {col} has values outside the allowed list {list(allowed)}.", v[col])
                row_ok = False
        if v["Complied"] != "" and v["Complied"] not in c.YES_NO:
            _add(errors, "invalid_complied", "Complied must be exactly Yes or No.", v["Complied"])
            row_ok = False
        if v["HHaction"] != "" and v["HHaction"] not in c.HH_ACTIONS:
            _add(errors, "unknown_hhaction", f"HHaction must be empty or one of {list(c.HH_ACTIONS)}.", v["HHaction"])
            row_ok = False
        if v["Missedbutglove"] != "" and v["Missedbutglove"] not in c.YES_NO:
            _add(errors, "unknown_missedbutglove", "Missedbutglove must be empty, Yes or No.", v["Missedbutglove"])
            row_ok = False
        opp: int | None = None
        if v["Opp"] != "":
            try:
                opp = int(v["Opp"])
                if opp <= 0:
                    raise ValueError
            except ValueError:
                _add(errors, "invalid_opp", "Opp must be a positive integer.", v["Opp"])
                row_ok = False
        if not row_ok:
            continue
        if opp is not None:
            opps.append(opp)
        rows.append(ParsedRow(rn, opp, v["Ward"], v["Profcat"], v["Shift"], v["Indication"],
                              v["HHaction"] or None, v["Missedbutglove"] or None, v["Complied"] == "Yes"))

    report.row_count = n_data
    if n_data == 0:
        return fail("no_rows", "The file has a header but no data rows.")
    report.errors.extend(errors.values())
    if errors:
        return report
    report.rows = rows

    # 3. data-contract checks -> warnings (the file is still importable)
    warnings: dict[str, Issue] = {}
    if len(opps) < len(rows):
        for r in rows:
            if r.source_opp is None:
                _add(warnings, "missing_source_opp", "Rows without an Opp value (stored as NULL).", r.row_number)
    seen, dups = set(), []
    for o in opps:
        if o in seen and o not in dups:
            dups.append(o)
        seen.add(o)
    if dups:
        w = Issue("duplicate_source_opp", "Opp values appear more than once. Opp is a sequence number, not a unique key.", len(dups), dups[:MAX_EXAMPLES])
        warnings[w.code] = w
    if opps:
        gaps = sorted(set(range(min(opps), max(opps) + 1)) - seen)
        if gaps:
            w = Issue("missing_source_opp_in_sequence", "Opp values missing from the sequence.", len(gaps), gaps[:MAX_EXAMPLES])
            warnings[w.code] = w
    for r in rows:
        if (r.hh_action is not None) != r.complied:
            _add(warnings, "hhaction_contract", "HHaction should be empty exactly when Complied = No (target leakage column).", r.row_number)
        if (r.missed_but_glove is None) != r.complied:
            _add(warnings, "missedbutglove_contract", "Missedbutglove should be empty exactly when Complied = Yes (target leakage column).", r.row_number)
    report.warnings.extend(warnings.values())
    return report
