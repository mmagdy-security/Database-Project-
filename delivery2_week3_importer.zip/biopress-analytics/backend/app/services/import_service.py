"""Writes a validated ImportReport to the database. The caller owns the transaction (commit/rollback)."""
from __future__ import annotations

import json
import os
from pathlib import Path

from sqlalchemy import insert, select
from sqlalchemy.orm import Session

from app.db import constants as c
from app.db.models import DataImport, Institution, Opportunity, Ward
from app.services.importer import ImportReport


class DuplicateImportError(Exception):
    """The exact same file (same SHA-256) was already imported."""


class InvalidReportError(Exception):
    pass


def ensure_reference_data(session: Session) -> int:
    """Idempotent: one institution and its five wards. Returns the institution id."""
    inst = session.scalar(select(Institution).where(Institution.name == c.INSTITUTION_NAME))
    if inst is None:
        inst = Institution(name=c.INSTITUTION_NAME)
        session.add(inst)
        session.flush()
    have = set(session.scalars(select(Ward.name).where(Ward.institution_id == inst.id)))
    for name in c.WARDS:
        if name not in have:
            session.add(Ward(institution_id=inst.id, name=name))
    session.flush()
    return inst.id


def find_import_by_sha(session: Session, sha256: str) -> DataImport | None:
    return session.scalar(select(DataImport).where(DataImport.sha256 == sha256))


def commit_import(session: Session, report: ImportReport, *, imported_by: int | None = None,
                  institution_id: int | None = None) -> DataImport:
    """Insert data_imports + all rows in the CURRENT transaction (flush only, no commit)."""
    if not report.ok or not report.rows:
        raise InvalidReportError("Only a valid report can be written.")
    if find_import_by_sha(session, report.sha256) is not None:
        raise DuplicateImportError(report.sha256)
    if institution_id is None:
        ids = list(session.scalars(select(Institution.id)))
        if len(ids) != 1:
            raise InvalidReportError("institution_id is required when there is not exactly one institution.")
        institution_id = ids[0]
    ward_ids = {w.name: w.id for w in session.scalars(select(Ward).where(Ward.institution_id == institution_id))}

    imp = DataImport(filename=os.path.basename(report.filename)[:255], sha256=report.sha256,
                     row_count=len(report.rows), status="committed", imported_by=imported_by,
                     notes=json.dumps([w.to_dict() for w in report.warnings]))
    session.add(imp)
    session.flush()
    session.execute(insert(Opportunity), [
        {"import_id": imp.id, "row_number": r.row_number, "source_opp": r.source_opp,
         "ward_id": ward_ids[r.ward], "profcat": r.profcat, "shift": r.shift, "indication": r.indication,
         "hh_action": r.hh_action, "missed_but_glove": r.missed_but_glove, "complied": r.complied}
        for r in report.rows
    ])
    return imp


def store_raw_upload(raw: bytes, sha256: str, upload_dir: Path) -> Path:
    """Keep the exact uploaded bytes, content-addressed and read-only. Never modified or deleted by the app."""
    upload_dir.mkdir(parents=True, exist_ok=True)
    path = upload_dir / f"{sha256}.csv"
    if not path.exists():
        try:
            with open(path, "xb") as fh:
                fh.write(raw)
            os.chmod(path, 0o444)
        except FileExistsError:
            pass
    return path
