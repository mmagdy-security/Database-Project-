"""Import validation: rejects bad files with a clear message, reports data-contract warnings, never fixes silently."""
import hashlib

import pytest

from app.services.importer import parse_and_validate

HEADER = "Ward,Profcat,Shift,Opp,Indication,HHaction,Missedbutglove,Complied"
GOOD = "Surgical,Nurse,Morning,1,Before patient contact,,No,No"
GOOD_YES = "Medical,Nurse,Night,2,After body fluid exposure,HW (hand wash),,Yes"


def csv(*lines: str, header: str = HEADER) -> bytes:
    return ("\n".join([header, *lines]) + "\n").encode()


def codes(issues):
    return {i.code for i in issues}


def test_original_file_reproduces_audit_numbers(raw_csv_bytes):
    r = parse_and_validate(raw_csv_bytes, "hand_hygiene_data_labeled.csv")
    assert r.ok and r.row_count == 917 and len(r.rows) == 917
    assert r.complied_yes == 202
    assert round(100 * r.complied_yes / r.row_count, 1) == 22.0
    assert r.sha256 == hashlib.sha256(raw_csv_bytes).hexdigest()


def test_original_file_warnings_are_the_known_opp_problems(raw_csv_bytes):
    r = parse_and_validate(raw_csv_bytes, "x.csv")
    by = {w.code: w for w in r.warnings}
    assert by["duplicate_source_opp"].examples == [788]
    assert by["missing_source_opp_in_sequence"].examples == [787]
    assert "hhaction_contract" not in by and "missedbutglove_contract" not in by   # target-dependence holds in the original file


def test_missing_required_column_is_rejected_with_clear_message():
    r = parse_and_validate(csv(GOOD, header="Ward,Profcat,Opp,Indication,HHaction,Missedbutglove,Complied"), "x.csv")
    assert not r.ok
    assert codes(r.errors) == {"missing_columns"}
    assert "Shift" in r.errors[0].message


def test_unknown_complied_value_is_rejected():
    r = parse_and_validate(csv(GOOD, "Surgical,Nurse,Morning,3,Before patient contact,,No,Maybe"), "x.csv")
    assert not r.ok and "invalid_complied" in codes(r.errors)
    assert r.errors[0].examples == ["Maybe"] or any(e.examples == ["Maybe"] for e in r.errors)


def test_unknown_categories_are_rejected_and_reported():
    r = parse_and_validate(csv("Cardiology,Nurse,Morning,1,Before patient contact,,No,No",
                               "Surgical,Janitor,Morning,2,Before patient contact,,No,No"), "x.csv")
    assert {"unknown_ward", "unknown_profcat"} <= codes(r.errors)
    assert r.rows == []                      # nothing is kept from a rejected file


def test_unexpected_column_is_rejected_not_stored():
    r = parse_and_validate(csv(GOOD + ",Alice", header=HEADER + ",PatientName"), "x.csv")
    assert codes(r.errors) == {"unexpected_columns"}
    assert r.errors[0].examples == ["PatientName"]


@pytest.mark.parametrize("name", ["data.xlsx", "data.csv.exe", "data"])
def test_only_csv_extension_is_accepted(name):
    assert codes(parse_and_validate(csv(GOOD), name).errors) == {"file_type"}


def test_size_limit_and_row_limit():
    assert codes(parse_and_validate(csv(GOOD), "x.csv", max_bytes=10).errors) == {"file_too_large"}
    assert codes(parse_and_validate(csv(GOOD, GOOD_YES, GOOD), "x.csv", max_rows=2).errors) == {"row_limit"}


def test_empty_and_header_only_files():
    assert codes(parse_and_validate(b"", "x.csv").errors) == {"empty_file"}
    assert codes(parse_and_validate((HEADER + "\n").encode(), "x.csv").errors) == {"no_rows"}


def test_non_utf8_is_rejected():
    assert codes(parse_and_validate(b"\xff\xfe\x00bad", "x.csv").errors) == {"encoding"}


def test_missing_values_in_required_columns_are_errors():
    r = parse_and_validate(csv(",Nurse,Morning,1,Before patient contact,,No,No"), "x.csv")
    assert "missing_value_ward" in codes(r.errors)


def test_invalid_opp_is_an_error_but_empty_opp_is_a_warning():
    assert "invalid_opp" in codes(parse_and_validate(csv("Surgical,Nurse,Morning,abc,Before patient contact,,No,No"), "x.csv").errors)
    r = parse_and_validate(csv("Surgical,Nurse,Morning,,Before patient contact,,No,No"), "x.csv")
    assert r.ok and "missing_source_opp" in codes(r.warnings) and r.rows[0].source_opp is None


def test_target_dependence_violations_are_warnings_not_silent_fixes():
    r = parse_and_validate(csv("Surgical,Nurse,Morning,1,Before patient contact,HW (hand wash),,No"), "x.csv")
    assert r.ok
    assert {"hhaction_contract", "missedbutglove_contract"} <= codes(r.warnings)
    assert r.rows[0].hh_action == "HW (hand wash)"        # stored as given, not "corrected"


def test_values_are_not_trimmed():
    r = parse_and_validate(csv("Surgical ,Nurse,Morning,1,Before patient contact,,No,No"), "x.csv")
    assert "unknown_ward" in codes(r.errors)


def test_utf8_bom_is_accepted():
    assert parse_and_validate(b"\xef\xbb\xbf" + csv(GOOD, GOOD_YES), "x.csv").ok
