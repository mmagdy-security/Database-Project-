import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# Defaults for collection time (app.main reads settings when imported).
os.environ.setdefault("APP_ENV", "test")
os.environ.setdefault("DATA_SOURCE", "csv")
os.environ.setdefault("REQUIRE_AUTH", "false")
os.environ.setdefault("SECRET_KEY", "test-secret-key-test-secret-key-0123456789")

RAW_CSV = Path(__file__).resolve().parents[2] / "data" / "raw" / "hand_hygiene_data_labeled.csv"


@pytest.fixture(autouse=True)
def _test_env(monkeypatch):
    """Legacy analytics tests run on the CSV without a token. Security tests override these per test."""
    monkeypatch.setenv("APP_ENV", "test")
    monkeypatch.setenv("DATA_SOURCE", "csv")
    monkeypatch.setenv("REQUIRE_AUTH", "false")
    monkeypatch.setenv("SECRET_KEY", "test-secret-key-test-secret-key-0123456789")
    monkeypatch.delenv("DATABASE_URL", raising=False)


@pytest.fixture
def raw_csv_bytes() -> bytes:
    return RAW_CSV.read_bytes()
