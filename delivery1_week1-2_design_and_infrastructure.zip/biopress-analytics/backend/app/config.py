"""Runtime configuration, read from environment variables only.

Rules (docs/architecture.md, security section):
- No secret has a default value. Missing secrets stop the app at start-up.
- Settings are read on every call so tests can change them with monkeypatch.setenv.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
_PLACEHOLDERS = {"", "change-me", "changeme", "replace-me", "replace-with-a-long-random-string"}


class ConfigError(RuntimeError):
    pass


def _bool(name: str, default: bool) -> bool:
    v = os.getenv(name)
    return default if v is None else v.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    env: str = "development"                 # development | test | production
    data_source: str = "csv"                 # csv | db
    database_url: str = ""                   # app_rw role (API)
    secret_key: str = ""                     # JWT signing key
    access_token_minutes: int = 15
    require_auth: bool = True                # protects analytics reads; admin/analyst routes are ALWAYS protected
    cors_origins: tuple[str, ...] = field(default_factory=tuple)
    upload_dir: Path = ROOT / "data" / "uploads"
    max_upload_bytes: int = 5 * 1024 * 1024
    max_rows: int = 20_000

    def validate(self) -> "Settings":
        if self.env not in {"development", "test", "production"}:
            raise ConfigError(f"APP_ENV must be development, test or production (got {self.env!r})")
        if self.data_source not in {"csv", "db"}:
            raise ConfigError("DATA_SOURCE must be 'csv' or 'db'")
        if self.data_source == "db" and not self.database_url:
            raise ConfigError("DATABASE_URL is required when DATA_SOURCE=db")
        if self.env == "production":
            if not self.require_auth:
                raise ConfigError("REQUIRE_AUTH cannot be false in production")
            if self.data_source != "db":
                raise ConfigError("DATA_SOURCE must be 'db' in production")
        return self

    def require_secret_key(self) -> str:
        if self.secret_key.strip().lower() in _PLACEHOLDERS or len(self.secret_key) < 32:
            raise ConfigError("SECRET_KEY must be set to a random string of at least 32 characters")
        return self.secret_key


def get_settings() -> Settings:
    origins = tuple(o.strip() for o in os.getenv("CORS_ORIGINS", "").split(",") if o.strip())
    return Settings(
        env=os.getenv("APP_ENV", "development"),
        data_source=os.getenv("DATA_SOURCE", "csv"),
        database_url=os.getenv("DATABASE_URL", ""),
        secret_key=os.getenv("SECRET_KEY", ""),
        access_token_minutes=int(os.getenv("ACCESS_TOKEN_MINUTES", "15")),
        require_auth=_bool("REQUIRE_AUTH", True),
        cors_origins=origins,
        upload_dir=Path(os.getenv("UPLOAD_DIR", str(ROOT / "data" / "uploads"))),
        max_upload_bytes=int(os.getenv("MAX_UPLOAD_BYTES", str(5 * 1024 * 1024))),
        max_rows=int(os.getenv("MAX_ROWS", "20000")),
    ).validate()
