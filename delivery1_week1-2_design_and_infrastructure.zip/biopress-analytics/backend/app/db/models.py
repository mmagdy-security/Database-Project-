"""SQLAlchemy 2.x models. Only what the data supports: no dates, workers or sessions tables."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import (JSON, Boolean, CheckConstraint, DateTime, ForeignKey, Index, Integer,
                        String, Text, UniqueConstraint, func)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from app.db import constants as c


def _in(column: str, values) -> str:
    quoted = ", ".join("'" + v.replace("'", "''") + "'" for v in values)
    return f"{column} IN ({quoted})"


class Base(DeclarativeBase):
    pass


class Institution(Base):
    __tablename__ = "institutions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200), unique=True, nullable=False)


class Ward(Base):
    __tablename__ = "wards"
    __table_args__ = (UniqueConstraint("institution_id", "name", name="uq_wards_institution_name"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    institution_id: Mapped[int] = mapped_column(ForeignKey("institutions.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)


class User(Base):
    __tablename__ = "users"
    __table_args__ = (CheckConstraint(_in("role", c.ROLES), name="ck_users_role"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    role: Mapped[str] = mapped_column(String(20), nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)


class DataImport(Base):
    __tablename__ = "data_imports"
    __table_args__ = (
        CheckConstraint(_in("status", c.IMPORT_STATUSES), name="ck_data_imports_status"),
        CheckConstraint("row_count >= 0", name="ck_data_imports_row_count"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    filename: Mapped[str] = mapped_column(String(255), nullable=False)
    sha256: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)  # same file cannot be imported twice
    row_count: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="committed")
    imported_by: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    imported_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON text: import warnings
    opportunities: Mapped[list["Opportunity"]] = relationship(back_populates="data_import")


class Opportunity(Base):
    __tablename__ = "hand_hygiene_opportunities"
    __table_args__ = (
        UniqueConstraint("import_id", "row_number", name="uq_opportunity_import_row"),
        CheckConstraint(_in("profcat", c.PROFCATS), name="ck_opp_profcat"),
        CheckConstraint(_in("shift", c.SHIFTS), name="ck_opp_shift"),
        CheckConstraint(_in("indication", c.INDICATIONS), name="ck_opp_indication"),
        CheckConstraint("hh_action IS NULL OR " + _in("hh_action", c.HH_ACTIONS), name="ck_opp_hh_action"),
        CheckConstraint("missed_but_glove IS NULL OR " + _in("missed_but_glove", c.YES_NO), name="ck_opp_missed"),
        CheckConstraint("complied IS NOT NULL", name="ck_opp_complied_not_null"),
        Index("ix_opp_import_id", "import_id"),
        Index("ix_opp_ward_id", "ward_id"),
        Index("ix_opp_indication", "indication"),
        Index("ix_opp_shift", "shift"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    import_id: Mapped[int] = mapped_column(ForeignKey("data_imports.id", ondelete="RESTRICT"), nullable=False)
    row_number: Mapped[int] = mapped_column(Integer, nullable=False)          # position in the uploaded file (1-based)
    source_opp: Mapped[int | None] = mapped_column(Integer, nullable=True)    # original Opp, NOT unique (788 twice)
    ward_id: Mapped[int] = mapped_column(ForeignKey("wards.id"), nullable=False)
    profcat: Mapped[str] = mapped_column(String(50), nullable=False)
    shift: Mapped[str] = mapped_column(String(50), nullable=False)
    indication: Mapped[str] = mapped_column(String(100), nullable=False)
    hh_action: Mapped[str | None] = mapped_column(String(50), nullable=True)           # leaky: never a model input
    missed_but_glove: Mapped[str | None] = mapped_column(String(10), nullable=True)    # leaky: never a model input
    complied: Mapped[bool] = mapped_column(Boolean, nullable=False)
    data_import: Mapped[DataImport] = relationship(back_populates="opportunities")


class ModelRun(Base):
    __tablename__ = "model_runs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    model_type: Mapped[str] = mapped_column(String(50), nullable=False)
    git_commit: Mapped[str | None] = mapped_column(String(40), nullable=True)
    data_import_id: Mapped[int | None] = mapped_column(ForeignKey("data_imports.id"), nullable=True)
    features: Mapped[list] = mapped_column(JSON, nullable=False)
    metrics: Mapped[dict] = mapped_column(JSON, nullable=False)
    artifact_path: Mapped[str | None] = mapped_column(String(500), nullable=True)


class AuditLog(Base):
    __tablename__ = "audit_log"
    __table_args__ = (Index("ix_audit_ts", "ts"), Index("ix_audit_action", "action"))
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    username: Mapped[str | None] = mapped_column(String(64), nullable=True)   # kept for failed logins
    action: Mapped[str] = mapped_column(String(50), nullable=False)
    resource: Mapped[str | None] = mapped_column(String(200), nullable=True)
    details: Mapped[dict | None] = mapped_column(JSON, nullable=True)         # never passwords/tokens
    ip: Mapped[str | None] = mapped_column(String(45), nullable=True)
