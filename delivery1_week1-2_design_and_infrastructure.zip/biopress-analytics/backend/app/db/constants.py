"""Single source of truth for allowed values (models, importer, tests and views all use this).

Values are copied from the real file (see docs/data_dictionary.md). Note the capital S in
'After contact with patient Surroundings': that is how it appears in the CSV.
"""
INSTITUTION_NAME = "Debre Berhan referral hospital"
WARDS = ("Ob/Gyn", "Paediatric", "Medical", "Surgical", "NICU")
PROFCATS = ("Nurse", "Medical doctor", "Midwife", "Other")
SHIFTS = ("Morning", "After noon", "Night")
INDICATIONS = (
    "Before patient contact",
    "Before an aseptic procedure",
    "After patient contact",
    "After contact with patient Surroundings",
    "After body fluid exposure",
)
YES_NO = ("Yes", "No")
HH_ACTIONS = ("HW (hand wash)", "HR (hand rub)")

REQUIRED_COLUMNS = ("Ward", "Profcat", "Shift", "Opp", "Indication", "HHaction", "Missedbutglove", "Complied")

# Columns that must never reach a model (target leakage) or be used as features.
LEAKY_COLUMNS = ("HHaction", "Missedbutglove")

ROLES = ("admin", "analyst", "viewer")
ROLE_RANK = {"viewer": 1, "analyst": 2, "admin": 3}
IMPORT_STATUSES = ("committed", "archived")
