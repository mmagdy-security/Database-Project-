"""Baseline schema: institutions, wards, users, data_imports, opportunities, model_runs, audit_log.

Revision ID: 0001
Revises:
"""
import sqlalchemy as sa
from alembic import op

from app.db import constants as c
from app.db.models import _in

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None



def upgrade() -> None:
    institutions = op.create_table(
        "institutions",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(200), nullable=False, unique=True),
    )
    wards = op.create_table(
        "wards",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("institution_id", sa.Integer, sa.ForeignKey("institutions.id"), nullable=False),
        sa.Column("name", sa.String(100), nullable=False),
        sa.UniqueConstraint("institution_id", "name", name="uq_wards_institution_name"),
    )
    op.create_table(
        "users",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("username", sa.String(64), nullable=False, unique=True),
        sa.Column("role", sa.String(20), nullable=False),
        sa.Column("password_hash", sa.String(255), nullable=False),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.CheckConstraint(_in("role", c.ROLES), name="ck_users_role"),
    )
    op.create_table(
        "data_imports",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("filename", sa.String(255), nullable=False),
        sa.Column("sha256", sa.String(64), nullable=False, unique=True),
        sa.Column("row_count", sa.Integer, nullable=False),
        sa.Column("status", sa.String(20), nullable=False, server_default="committed"),
        sa.Column("imported_by", sa.Integer, sa.ForeignKey("users.id", ondelete="SET NULL")),
        sa.Column("imported_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("notes", sa.Text),
        sa.CheckConstraint(_in("status", c.IMPORT_STATUSES), name="ck_data_imports_status"),
        sa.CheckConstraint("row_count >= 0", name="ck_data_imports_row_count"),
    )
    op.create_table(
        "hand_hygiene_opportunities",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("import_id", sa.Integer, sa.ForeignKey("data_imports.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("row_number", sa.Integer, nullable=False),
        sa.Column("source_opp", sa.Integer),
        sa.Column("ward_id", sa.Integer, sa.ForeignKey("wards.id"), nullable=False),
        sa.Column("profcat", sa.String(50), nullable=False),
        sa.Column("shift", sa.String(50), nullable=False),
        sa.Column("indication", sa.String(100), nullable=False),
        sa.Column("hh_action", sa.String(50)),
        sa.Column("missed_but_glove", sa.String(10)),
        sa.Column("complied", sa.Boolean, nullable=False),
        sa.UniqueConstraint("import_id", "row_number", name="uq_opportunity_import_row"),
        sa.CheckConstraint(_in("profcat", c.PROFCATS), name="ck_opp_profcat"),
        sa.CheckConstraint(_in("shift", c.SHIFTS), name="ck_opp_shift"),
        sa.CheckConstraint(_in("indication", c.INDICATIONS), name="ck_opp_indication"),
        sa.CheckConstraint("hh_action IS NULL OR " + _in("hh_action", c.HH_ACTIONS), name="ck_opp_hh_action"),
        sa.CheckConstraint("missed_but_glove IS NULL OR " + _in("missed_but_glove", c.YES_NO), name="ck_opp_missed"),
        sa.CheckConstraint("complied IS NOT NULL", name="ck_opp_complied_not_null"),
    )
    op.create_index("ix_opp_import_id", "hand_hygiene_opportunities", ["import_id"])
    op.create_index("ix_opp_ward_id", "hand_hygiene_opportunities", ["ward_id"])
    op.create_index("ix_opp_indication", "hand_hygiene_opportunities", ["indication"])
    op.create_index("ix_opp_shift", "hand_hygiene_opportunities", ["shift"])
    op.create_table(
        "model_runs",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("model_type", sa.String(50), nullable=False),
        sa.Column("git_commit", sa.String(40)),
        sa.Column("data_import_id", sa.Integer, sa.ForeignKey("data_imports.id")),
        sa.Column("features", sa.JSON, nullable=False),
        sa.Column("metrics", sa.JSON, nullable=False),
        sa.Column("artifact_path", sa.String(500)),
    )
    op.create_table(
        "audit_log",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("ts", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("user_id", sa.Integer, sa.ForeignKey("users.id", ondelete="SET NULL")),
        sa.Column("username", sa.String(64)),
        sa.Column("action", sa.String(50), nullable=False),
        sa.Column("resource", sa.String(200)),
        sa.Column("details", sa.JSON),
        sa.Column("ip", sa.String(45)),
    )
    op.create_index("ix_audit_ts", "audit_log", ["ts"])
    op.create_index("ix_audit_action", "audit_log", ["action"])

    # Reference data: one institution, five wards (nothing else is invented).
    op.bulk_insert(institutions, [{"id": 1, "name": c.INSTITUTION_NAME}])
    op.bulk_insert(wards, [{"institution_id": 1, "name": n} for n in c.WARDS])


def downgrade() -> None:
    for t in ("audit_log", "model_runs", "hand_hygiene_opportunities", "data_imports", "users", "wards", "institutions"):
        op.drop_table(t)
