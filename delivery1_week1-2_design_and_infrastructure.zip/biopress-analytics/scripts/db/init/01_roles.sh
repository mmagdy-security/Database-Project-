#!/bin/bash
# Runs once, when the Postgres data volume is first created (docker-entrypoint-initdb.d).
# Passwords come from the container environment; psql :'var' quotes them safely.
set -euo pipefail

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" \
  -v mig_pw="$MIGRATION_OWNER_PASSWORD" -v app_pw="$APP_RW_PASSWORD" \
  -v ana_pw="$ANALYTICS_RO_PASSWORD" -v agent_pw="$AGENT_RO_PASSWORD" <<'EOSQL'
CREATE ROLE migration_owner LOGIN PASSWORD :'mig_pw';
CREATE ROLE app_rw          LOGIN PASSWORD :'app_pw';
CREATE ROLE analytics_ro    LOGIN PASSWORD :'ana_pw';
CREATE ROLE agent_ro        LOGIN PASSWORD :'agent_pw';

-- Only migration_owner may create objects; the others get privileges from the Alembic grants.
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO migration_owner;
SELECT format('GRANT CONNECT ON DATABASE %I TO migration_owner, app_rw, analytics_ro, agent_ro', current_database()) \gexec
SELECT format('REVOKE ALL ON DATABASE %I FROM PUBLIC', current_database()) \gexec
EOSQL
