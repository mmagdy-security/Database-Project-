# Architecture (Database & Security view)

Owner of this document's database and security sections: Database & Security team.
The API and ML sections are completed by the other teams.

## 1. Data flow

```
raw CSV (read-only, data/raw)  ──►  importer (validate, warn)  ──►  PostgreSQL  ──►  views  ──►  API  ──►  dashboard
 uploaded CSV (data/uploads, read-only copy, named by SHA-256) ─┘                    │
                                                                                     ├─ v_ml_features      → AI team (5 columns only)
                                                                                     ├─ v_compliance_facts → analytics/API
                                                                                     └─ v_import_summary   → agents/auditors
```

## 2. ERD

Only what the data supports. There are **no** tables for dates, workers, patients or sessions: the data has none, and we do not invent them.

```mermaid
erDiagram
    institutions ||--o{ wards : has
    wards ||--o{ hand_hygiene_opportunities : "observed in"
    data_imports ||--o{ hand_hygiene_opportunities : contains
    users |o--o{ data_imports : imported_by
    users |o--o{ audit_log : actor
    data_imports |o--o{ model_runs : "trained on"

    institutions { int id PK  string name UK }
    wards { int id PK  int institution_id FK  string name }
    users { int id PK  string username UK  string role  string password_hash  bool is_active  datetime created_at }
    data_imports { int id PK  string filename  string sha256 UK  int row_count  string status  int imported_by FK  datetime imported_at  text notes }
    hand_hygiene_opportunities {
        int id PK
        int import_id FK
        int row_number "unique with import_id"
        int source_opp "original Opp, NOT unique (788 twice)"
        int ward_id FK
        string profcat "CHECK allowed list"
        string shift "CHECK allowed list"
        string indication "CHECK allowed list"
        string hh_action "nullable, LEAKY"
        string missed_but_glove "nullable, LEAKY"
        bool complied "NOT NULL"
    }
    model_runs { int id PK  datetime created_at  string model_type  string git_commit  int data_import_id FK  json features  json metrics  string artifact_path }
    audit_log { int id PK  datetime ts  int user_id FK  string username  string action  string resource  json details  string ip }
```

Design decisions

| Decision | Reason |
|---|---|
| Unique key is `(import_id, row_number)`; `source_opp` is stored as-is | Opp 788 appears twice and 787 is missing. Opp is a sequence number, not an identifier. |
| `profcat`, `shift`, `indication`: text with `CHECK` against the allowed list; ward through the `wards` lookup table | Unknown categories are rejected at import and reported, and cannot be inserted by any other path. |
| `complied` is `NOT NULL` (+ explicit CHECK) | The target must always be known. |
| `data_imports.sha256` is `UNIQUE` | Ties every analysis to an exact file and stops double imports. |
| `status` (`committed` / `archived`); views show only `committed` | A bad import is archived, never deleted. |
| Indexes: `import_id`, `ward_id`, `indication`, `shift` | Filters used by the dashboard. |
| `hh_action` and `missed_but_glove` are stored but only reachable from the table, never from a view | They are kept for the audit (descriptive use among non-compliant staff), and cannot leak into a model by accident. |

Views (`backend/app/db/sql_views.py`, created by migration `0002`)

| View | Columns | Reader |
|---|---|---|
| `v_ml_features` | `ward, profcat, shift, indication, complied` | AI team (training data only from here) |
| `v_compliance_facts` | `ward, shift, profcat, indication, n, complied_count` | API / analytics |
| `v_import_summary` | `id, filename, sha256, row_count, status, imported_at, notes` (warnings as JSON) | agents, auditors (no uploader identity) |

## 3. Import pipeline

1. Only `.csv`, at most `MAX_UPLOAD_BYTES` (5 MB) and `MAX_ROWS` (20 000).
2. Validate required columns, exact allowed values (no trimming, no "fixes"), types. **Unexpected columns are rejected**, not stored (data minimisation).
3. Data-contract checks, reported as warnings and stored in `data_imports.notes`: duplicated `Opp`, `Opp` gaps, `HHaction` empty exactly when `Complied = No`, `Missedbutglove` empty exactly when `Complied = Yes`, missing `Opp`.
4. `POST /api/v1/imports/preview` shows the report and writes nothing.
5. `POST /api/v1/imports/confirm` re-validates the same bytes, refuses if the SHA-256 differs from the previewed one, then writes `data_imports`, all rows and the audit entry **in one transaction**.
6. The uploaded bytes are stored unchanged and read-only as `data/uploads/<sha256>.csv`. Cleaning, if ever needed, happens in processed copies.

Result for the original file: 917 rows, 202 complied (22.0%), warnings `duplicate_source_opp [788]` and `missing_source_opp_in_sequence [787]`, no target-dependence violation.


> The Security section (4) and Known limits (5) are added in Delivery 6.
> The views listed above are created in Delivery 3 (migration 0002).
