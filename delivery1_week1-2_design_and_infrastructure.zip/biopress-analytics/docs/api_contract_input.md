# API contract input from Database & Security (for the week-2 OpenAPI freeze)

All paths are under `/api/v1`. Authentication: `Authorization: Bearer <JWT>`. Errors use FastAPI's `{"detail": ...}`.

| Method | Path | Role | Purpose |
|---|---|---|---|
| POST | `/auth/login` | public (rate limited) | JSON `{username, password}` → `{access_token, token_type, expires_in}` |
| GET | `/auth/me` | any valid token | `{username, role}` |
| POST | `/admin/users` | admin | create user `{username, password (>=12), role}` |
| GET | `/admin/users` | admin | list users (no hashes) |
| POST | `/imports/preview` | admin | multipart `file` → validation report, writes nothing |
| POST | `/imports/confirm` | admin | multipart `file` + form `expected_sha256` → 201 `{import_id, sha256, row_count, complied_yes, warnings}` |
| GET | `/imports` | admin | list imports |
| GET | `/exports/summary.csv` | analyst | sanitized aggregate export |
| GET | `/analytics/summary`, `/analytics/by-{ward,shift,indication,profcat}` | viewer | unchanged contract; now read from the database |
| POST | `/ml/train` | admin, development only | security gate; AI team implements the body |

Status codes the frontend must handle: 401 (login again), 403 (hide the feature for this role), 409 (file already imported / differs from preview), 422 (validation errors; body contains the report), 429 (retry later), 503 (no data imported yet).

Import report shape (`/imports/preview`): `filename, sha256, size_bytes, row_count, ok, complied_yes, complied_no, errors[], warnings[], preview[], already_imported, can_confirm`; each issue is `{code, message, count, examples[]}`.

Export columns: `dimension, group, n, complied, rate, ci_low, ci_high, sample_flag (ok | small_sample | withheld), chi_square_p, note`. `rate`, `ci_low`, `ci_high` are empty when `sample_flag = withheld` (n < 5).

Request to the shared API owners (needs two reviewers): `analytics.by_group` still returns rates for groups with n < 5; the dashboard must apply the same rule (`app/services/export_safety.py: sample_status`) until the service does.
